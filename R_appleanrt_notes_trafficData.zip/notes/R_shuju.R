#### 数据处理 ####
  # 载入tidyverse包，则magrittr包，readr包，dplyr包和tidyr包都会被自动载入
 #### dim(),str(),glimpse() #### 
 --查看数据框一般信息
          dim(data) # 获得行数和列数
          names(data) # 获得各列变量名
          str(data) # 显示类型、大小、各列变量名、前几个值、属性
          dplyr::glimpse(data) # 显示数据框大小、各列变量名、类型
  #### filter(),slice(),select() ####
  --用filter()选择行子集
          d.class |>
            filter(sex=="F", age<=13) |> # filter函数:参数1--数据框,后续参数--同时满足的条件
            knitr::kable()               # filter函数自动舍弃行名
  --按行序号选择行子集
          head(data,n) tail(data,n) # 选择数据框前面或者后面n行
          d.class |>
            slice(3:5) |>           # slice(data,)选择指定序号的行子集,正的序号表示保留,负的序号表示排除
            knitr::kable()          # slice(data,prop=0.1) 输入要提取的行数的比例
  --用select()选择列子集
          # 指定列变量名
          d.class |>
            select(name, age) |>
            head(n=3) |>
            knitr::kable()
          # 用冒号表示列范围
          d.class |>
            select(age:weight) |>  # select(3:5)数字序号也可表示列的范围,前面加-号表示扣除
            head(n=3) |>
            knitr::kable()
          # 要选择的变量名已经保存为一个字符型向量,可以用all_of()函数引入
          vars <- c("name", "sex")
          d.class |>
            select(all_of(vars)) |>
            head(n=3) |>
            knitr::kable()
          # 选择变量时， 可以用“新变量=老变量”的格式同时改名
          d.class |>
            select(id = name, gender=sex) |>
            head(n=3) |>
            knitr::kable()
  #### sample_n ####
  --用sample_n对观测随机抽样
          d.class |>
            sample_n(size = 3) |>   # dplyr::sample_n(tbl,size) 从数据框中随机无放回抽取size行
            knitr::kable()          # sample_n()加选项replace=TRUE变成有放回抽样,用weight选项指定一列作为抽样权重,进行不等概抽样
  #### distinct()、drop_na() ####
  --用distinct()去除重复行
          d.class |>
            distinct(sex, age) |>   # distinct()指定变量名时,不是写成字符串形式,而是直接写变量名 -- dplyr和tidyr包的特点
            knitr::kable()          # 希望保留数据框中其他变量,加选项.keep_all=TRUE
          NHANES |>
            distinct(ID, SurveyYr) |>
            nrow()                  # 查看NHANES数据框中ID与SurveyYr的组合的不同值的个数
   --用drop_na()去除指定的变量有缺失值的行
            NHANES |>
              drop_na() |>           
              nrow() 
            # 将NHANES中所有存在缺失值的行删去后数出保留的行数
            NHANES |>
              drop_na(AlcoholDay) |>
              nrow()
            # 仅剔除AlcoholDay缺失的观测并计数
    
      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
  #### pull()/arrange()/rename()/relocate()/mutate() ####
    --取出单个变量为向量
             # dplyr::pull()
             d.class |> 
              head(n=3) |>
              pull(name) |>        # dplyr::pull()
              paste(collapse=":")
            
              varname <- "name"
             d.class |> 
               head(n=3) |>
               select(one_of(varname)) |> # 先选择仅有一个变量的子数据框,再用pull()
               pull() |>
               paste(collapse=":")  
    --用arrange()排序
             # 按照数据框的某一列或者几列排序
             d.class |>
               arrange(sex,age) |>
               kniter::kabel()
             # desc()包裹想要降序排列的变量
             d.class |>
               arrange(sex,desc(age)) |>
               kniter::kable()
    --用rename()修改变量名
             # rename()用“新名字=旧名字”格式修改变量名
             d2.class <-  d.class |>
               dplyr::rename(h=height,w=weight)
    --用relocate()调整变量次序
             # relocate(df,var1,var2)将指定的变量调整到最前面
             d.class |>
               relocate(height,weight) |>
               head(n=3) |>
               kniter::kable()
             # .before指定一个变量名或变量序号,用.after指定一个变量， 使得指定的变量调整到此变量后面
             d.class |>
               relocate(height,weight,.after=name) |>
               head(n=3) |>
               kniter::kable()
    --用mutate()计算新变量
             # mutate()计算新变量,返回新旧变量的数据框
             d.class |>
               mutate(
                 rwh=weight/height,
                 sexc=dplyr::if_else(sex='F',"女","男")) |>
                 head(n=3 |>
                 kniter::kable()
             
              d.class |>
               mutate(
                 sexc={
                   x <- rep("男",length(sex))
                   x[!is.na(sex)&sex='F'] <- '女' # 计算新变量计算复杂则可用多个语句组成复合语句
                   x
                 }) |>
               head(n=3)|>
               kniter::kable()
             # 计算公式可包含对数据框中变量的统计函数结果
              d.class |>
                mutate(
                  cheight = height - mean(height)) |>
                knitr::kable()
              
               
          
             
             
             
             
             
             
             
             
             
             
             
             
              