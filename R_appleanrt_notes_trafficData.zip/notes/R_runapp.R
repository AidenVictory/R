#### runapp ####
  ####  create shinnyapp ####
    # Make a directory named myapp
    # Save  app.R script inside that directory.
    # Launch the app with runApp
    # Exit the Shiny app by clicking escape

  #### pre-shinnyapp ####
      runExample("01_hello")      # a histogram                             -- automatic UI updates
    # 
      # **fluidPage: sidebar pannel/main pannel /
      runExample("02_text")       # tables and data frames                  -- output of raw text from R 
                                                               # using the renderPrint function in server  
                                                               # the verbatimTextOutput function in ui --verbatimTextOutput("summary")
      runExample("03_reactivity") # a reactive expression                   -- reactivity
                                                               # reactive called *datasetInput* in the server
      runExample("04_mpg")        # global variables
      runExample("05_sliders")    # slider bars
      runExample("06_tabsets")    # tabbed panels
      runExample("07_widgets")    # help text and submit buttons
      runExample("08_html")       # Shiny app built from HTML
      runExample("09_upload")     # file upload wizard
      runExample("10_download")   # file download wizard
      runExample("11_timer")      # an automated timer
      
  #### build a user interface  ####
      #### HTML tag functions ####
        	p <p>	A paragraph of text
              # p("hello",style="font-family:'times';font-si16pt"),
          h1	<h1>	A first level header
              #    
          h2	<h2>	A second level header
          h3	<h3>	A third level header
          h4	<h4>	A fourth level header
          h5	<h5>	A fifth level header
          h6	<h6>	A sixth level header
          a	<a>	A hyper link
          br	<br>	A line break (e.g. a blank line)
            # br(),
          div        <div>	A division of text with a uniform style
              # div("hello",style="color:blue"),	 
          span  <span>	An in-line division of text with a uniform style
              # span("group of words",style="color:blue")	 
          pre	<pre>	Text ‘as is’ in a fixed width font
          code	<code>	A formatted block of code
          img  <img>	An image
            #  img(src = "rstudio.png", height = 140, width = 400)	 
            # png file keep in "www" folder -> the same dictory as the app.R
          strong	<strong>	Bold text
          em	<em>	Italicized text
          HTML	 	Directly passes a character string as HTML code
          ## 
      #### add control widgets ####
          function	--widget
          actionButton	--Action Button
          checkboxGroupInput	--A group of check boxes
          checkboxInput	--A single check box
          dateInput	--A calendar to aid date selection
          dateRangeInput	--A pair of calendars for selecting a date range
          fileInput	--A file upload control wizard
          helpText	--Help text that can be added to an input form
          numericInput	--A field to enter numbers
          radioButtons	--A set of radio buttons
          selectInput	--A box with choices to select from
          sliderInput	--A slider bar
          submitButton	--A submit button
          textInput	--A field to enter text
          ## go further -- shiny widgets gallery
          # https://shiny.rstudio.com/gallery/widget-gallery.html
          
          
          
          
          
          
          