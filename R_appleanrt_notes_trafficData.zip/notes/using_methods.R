---- R语言笔记 ---

#### 基操 ####
  #### 加载包&查看函数 ####
        install_github("badbye/baidumap") # 从github安装包
        installed.packages() #加载包
        example(solve) #使用example()查看该函数的使用范例
        cat("我爱","帅帅龙",sep="love") #输出-print不能指定sep-cat可以
        a = paste("我爱","帅帅龙",1,"万年",sep = xx) # 字符串拼接，非字符串类型直接转化为字符串
  #### 运算符号 #### 
        library(magrittr) # 调用管道符号的包
         %>% #管道符号
         %/% #整除符号
         %%  #求余符号
  #### 控制台操作 ####
        ctrl+L  # 清屏
        rm(list=ls())  # 清除内存空间
        getwd()  # 查看工作目录
        setwd()  # 设置临时目录
  #### 常见常量 ####
        LETTERS--letters--month.abb--month.name--pi(pai值) # 前几组均为向量
  #### 数据类型转换 ####
          # 文本转数值
            as.integer("12.3") as.double("11.666")
          # 数值转字符串
            a = paste(1)
            formatC(1/3, format = "e", digits = 4)  # digits表示小数点位数
            formatC(1/3, format = "f", digits = 4)
            a = as.character(18)
      




#### 常用数据结构 #### 
  #### 矩阵 ####
              
      ---创建,查看和命名---
              matrix(data = NA, nrow = 1, ncol = 1, byrow = FALSE, dimnames = NULL) 
              # byrow 横着分布,data矩阵数据，通常为向量
              head(a,10) tail(a,10)  rbind(c(1,2),c(3,4))  cbind(c(11,12),c(13,14))
              # 对矩阵行标和列标重新命名
              rownames(A)  <- c("a", "b", "c")
              colnames(A) <- paste("X", 1:4, sep="")
      ---常用函数---
               #  apply() --对矩阵某行或某列进行计算 
                        apply(x, margin, fun, …)
                        apply(A, 1, sum)
                        apply(A, 2, mean) # x表示矩阵，margin=1表示对每行计算，margin=2表示对每列计算，fun是用来计算的函数
               # tapply()函数 --分组函数计算
                        tapply(x, INDEX, FUN=NULL,…,simplify=TRUE) # x是一对象，通常为向量;inddex 与x相同长度的因子
                        sex = c("M","F","M","M","F")
                        height = c(174, 165, 180, 171, 160)
                        tapply(height, sex, mean)
               # 排序
                        x = c(1,7,5,4,4,6,9)
                        x = sort(x,decreasing=FALSE) 
                        x_order = order(x,decreasing=FALSE)
                        x[order(x[,1],x[,2]),]
  #### 因子 ####
      ---创建因子---        
              # 把一个向量编码为因子
              factor(x, levels = sort(unique(x), na.last = TRUE), labels, exclude = NA, ordered = FALSE)
              sex = c("M","F","M","M","F")
              sexf = factor(sex)    # 创建因子
      ---常用函数---
              is.factor() # 检验对象是否是因子
              as.factor() # 把向量转化为因子
              levels(x)   # 可以得到因子的水平
              table(x)    # 统计各类数据的频数
              
  #### 列表 ####
           rec <- list(name="黎明", age=30, scores=c(85,76,90)) # 创建列表
           # 列表的引用和修改 --列表不同于向量，每次只能引用一个元素
              rec[[2]] / rec[[2]] / rec$age / rec[["age"]] / rec[[2]]=11
           
  #### 向量 ####
        ---- 特点----
                  # 只能存放一种元素
                  # 索引从1开始
                  # 切片操作，两边都是闭区间
        ---- 向量创建 ----
                  a = c("我","爱","帅帅龙")
                  x <- seq(1, 10, by = 0.5) 
                  x <- rep(2:5, 2)
                  x <- rep(2:5, rep(2, 4)) 
        ---- 向量合并 ----
                  B=rbind(c(1,2),c(3,4)) # 两个向量上下合并
                  C=cbind(c(11,12),c(13,14)) #两个向量左右合并
        ---- 向量运算 ----
                  good_sample_p <- append(good_sample_p,p) #添加
                  sort(x, decreasing=FALSE) # 按x元素从小到大排序的结果向量
                  ort(x),x[order(x)] #
                  a <- numeric(n) # 长度为n的向量
                  # 字符向量/逻辑向量/复数向量
                  x[-4]  # 删除第四个元素
                  age1 = c(21, 34, 56)
                  names(age1) = c("Zhang", "Ding", "Liu")
  #### 数据框 ####
    #### 创建,引用，修改,添加,删除 ####
          # 创建,as.data.frame(list) 将list转换为dataframe
                d = data.frame(name=c('黎明','周杰伦','刘德华'),age=c(30,35,28),height=c(180,175,173))
          # 引用
                  d[1:2, 2:3] ; d[1:2, 2:3] ; d$height ; 
          # 定义行名/列名
                  rownames(d) = c("one", "two", "three")
                  colnames(d) <- paste()
          # 修改值
                  d$name[1] = "我爱你" 
                  d[1,2] = "女"
                  d[[1]][2] = "我爱你"  # 第一列第二个值
          # 添加
                  d = df1[-2,] ; d = df1[,-3] ; d = df1[-c(1,3),] ; d$r = age/weight
    #### 常用函数 ####
         ----attach()函数----
                  d = data.frame(name=c('黎明','周杰伦','刘德华'),age=c(30,35,28),height=c(180,175,173))
                  attach(d)
                  r <- age/height    # /对r进行修改不会影响d的数据
                  detach(d)          # 取消连接
         ----merge()函数----
                  merge(data1, data2, by='ID')  # 2个数据框合并为一个数据框
         ---- 查看数据类型 ---- 
                  str(数据框名字)
                  # 终端最后显示的UADRA ST" ... 后的几行即为崩溃位置,可以作为检验是否具有缺失值的条件
                  
                  
                  
    #### 数据框合并 ####  
        # 数据框自我数据连接横向合并，id和name合并为新字段he
            data00$he=paste(data00$id,data00$name,data00$he, sep = "")
            head(data00)
        # 两个数据框通过相同的元素横向合并
            hdata<-merge(data11,data33,by=id)
            head(hdata)
        # 多个数据框上下合并
            data01<- bind_rows(data1.1,data1.2,data1.3) or data01 <- rbind(data1.1,data1.2)
        # 合并数据框中两列为一列
            library(tidyr)
            data<-unite(data,"time",'date','timed',sep=" ",remove=TRUE)
        # _join
            library(dplyr)
            inner_join(class1,class2,by='名次') # 内连接--交集
            left_join(class1,class2,by='名次')  # 左连接
            right_join(class1,class2,by='名次') # 右连接
            full_join(class1,class2,by='名次')  # 并集

    #### 数据框排序 ####
            library(dplyr)
            data <- arrange(data,number,time)   # arrange
            data <- data[order(data$number,data$time),decreasing = FAlSE]  # order 均可按照多列排序, decreasing = FALSE 为升序排列
            mtcars %>% subset(cyl == 4 | cyl == 6) %>% subset(mpg<25) %>% subset(wt <3) %>% select(cyl,mpg) %>% plot()
            table(data$xx,data$xx)   # 即可形成od矩阵
            
    #### 数据框的筛选过滤 ####
            df <- data %>% dplyr::filter(!is.na(Latitude))
            df <- filter(data, data$Latitude == 0)
  #### 列联表 ####
      ----概念----
          # 聚焦于类别变量的频数表和列联表
    #### 一维列联表 ####
        ----可以使用table(x),xtab(formula = ~),crosstable()来创建----
                #生成一维列联表
                table(Arthritis$Improved) #方法一
                xtabs(formula = ~Arthritis$Improved) #方法二
                with(Arthritis,table(Improved)) #方法with
                library(vcd)
                library(gmodels)
                CrossTable(Arthritis$Improved) #方法三
                prop.table(table(Arthritis$Improved)) #转化为比例值
    #### 二维列联表 ####
         ----具有行和列两个维度,用于对两个因子变量一起分析----
                library(gmodels)
                library(vcd)
                #生成二维列联表
                table(Arthritis$Improved,Arthritis$Treatment) #方法一
                xtabs(formula = ~Arthritis$Improved+Arthritis$Treatment) #方法二
                gmodels::CrossTable(Arthritis$Improved,Arthritis$Treatment) #方法三
                with(Arthritis,table(Improved,Sex)) # 方法with
                
                prop.table(table(Arthritis$Improved,Arthritis$Treatment)) #生成比例
                margin.table(table(Arthritis$Improved,Arthritis$Treatment),1) #生成边际频数 = 分别计算各自频数
                addmargins(table(Arthritis$Improved,Arthritis$Treatment)) #添加边际和
                addmargins(table(Arthritis$Improved,Arthritis$Treatment),1) #添加列边际和
                addmargins(table(Arthritis$Improved,Arthritis$Treatment),2) #添加行边际和
                addmargins(table(Arthritis$Improved,Arthritis$Treatment)) #行列边际和都添加
    #### 多维列联表 ####
                
                library(gmodels)
                library(vcd)
                #生成多维列联表
                table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex) #方法一
                xtabs(~Arthritis$Improved+Arthritis$Treatment+Arthritis$Sex) #方法二
                ftable(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex)) #输出更紧凑的形式
                
                prop.table(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex))
                margin.table(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex))
                margin.table(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex),1)
                margin.table(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex),-1)
                addmargins(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex)) #三维都加和
                addmargins(table(Arthritis$Improved,Arthritis$Treatment,Arthritis$Sex),1) #行加和
                

                
                

                
#### 常用函数 ####            
  #### 流程控制 ####
    # if语句
            x <- 50L
            if(is.integer(x)) {
              print("X 是一个整数")
            } else {
              print("X 不是一个整数")
            }
    # while语句
            a = 1
            while(a<5){
              print('hello')
            }
    # for循环
            a = c([1:4])
            for(i in a){
              print(i)
            }
    # repeat循环
            a = 1
            sum = 0
            repeat{
              if(sum>10){
                break  # break终止循环，next继续下一次循环，就好像c++或python的continue
              }
              sum=sum+a
              a=a+1
            }
            print(sum)
            
        
  
  #### 数学函数 ####
        ----数学函数----
                  sqrt(n) --- exp(n) --- log(m,n) #n的对数函数，返回n的几次方等于m 
                  log10(m)  # 相当于log(m,10)
                  abs(x)\sin(x)\cos(x)\tan(x)
        ----取整函数----
                  round(n) # 对n四舍五入取整
                  round(n,m) # 对n保留m位小数四舍五入 
                  ceiling(n) # 对n向上取整
                  floor(n)   # 对n向下取整
                  # **** R 中的 round 函数有些情况下可能会"舍掉五",当取整位是偶数的时候,五也会被舍去 ****
        ####统计常用函数####
                  # 中位数/平均数
                    a=c(1:6)
                    mean(a) / median(a)  mean(a,na.rm = TRUE) # 计算平均值时,忽略缺失值
                  # 获取众数
                        # 创建函数
                        getmode = function(v) {
                          uniqv = unique(v)  # unique主要是返回一个把重复元素或行给删除的向量、数据框或数组
                          uniqv[which.max(tabulate(match(v, uniqv)))]
                        }
                        # 创建向量
                        v = c(2,1,2,3,1,2,3,4,1,5,5,3,2,3)
                        # 调用函数
                        result = getmode(v)
                        print(result)
                  # quantile()百分位,默认为5个
                        a=c(1:6)
                        quantile(a)
                  # summary():描述统计量 --最小值,最大值,四分位数,均值
                        a=c(1:6)
                        summary(a)
                  # 方差,标准差
                        a = c(1:5)
                        var(a)
                        sd(a)
                  # 变异系数 = 方差除以平均值
                  # 计算两个变量之间的相关系数
                        cor(height,log(height))
                  # 计算两个变量之间的协方差
                        cov(height,log(height))
            
  #### R markdown 谢益辉####
        # R 代码+ markdown -->  Rmd --> knitr --> pandoc(文档转换) --> HTML\word\PDF\RTF\
        # 三个部分
           # --- YAML header  格式外观，输出格式
           # --- 带格式文本   Markdown Tex html
           # --- Code Chunks  R or python
#### 数据读取 ####
  #### 读取数据框 ####
        # 读取csv:
        data <- read.csv("路径")
        data <- readr::read_csv("D:/documents/stu/traffic/data/work2/1.csv") # csv文件中有一列为中文
        # 读取xlsx：
        library(readxl)
        data1<- read_excel("路径")
        # 读取txt
        read.table(“filename.txt”)
        # 查看表头表尾
        head() /  tail()
        
              

        

        
        
        
        
        
#### 绘图 ####
  #### 图形参数设置 ####
        title("a",adj=0) # adj=0,标题左对齐,1-右对齐,0.5居中
        par(mfrow=c(1,1), mai=c(0.7, 0.7, 0.4, 0.4), cex=0.8,bty="o") 
        # bty = "o","7","c","u","]" 即图框如其符号
        # 
  #### 常见图形 ####
       #### barplot ####
           ---条形图---
                  res1 <- table(d.cancer[,'sex']) # res为table对d.cancer的sex列进行分类计数
                  barplot(res1, width=0.5, xlim=c(-3, 5),ylim=(1:5),main="性别分布", col=c("brown2", "aquamarine1"))
            # 一维列联表的条形图
            # main为标题,col设置条形不同颜色,width配合调整条形宽度,xlim和ylim分别调整x轴和y轴的范围
                  res2 <- with(d.cancer, table(sex, type))
                  barplot(res2, legend=TRUE) # 用分段条形图表现交叉分组频数， 交叉频数表每列为一条
                  barplot(res2, beside=TRUE, legend=TRUE) # 用并排条形图表现交叉分组频数， 交叉频数表每列为一组
            # 二维列联表的条形图
            # beside = TRUE 决定列联表的条形分段; legend = TRUE 决定图例的出现与否
       #### hist ####
          ---直方图和密度估计图---
                  x <- rnorm(30, mean=100, sd=1)
                  print(round(x,2))
                    hist(x,main = "x", xlab = "a",ylab = "b",col=rainbow(28),border = 'white')
            # 用hist作直方图以了解连续取值变量分布情况,main,xlab,ylab,col
                  tmp.dens <- density(x)
                  lines(tmp.dens, lwd=2, col='blue')
            # 在直方图上,绘制密度曲线
       #### boxplot ####
            ----盒形图-简洁表现变量分布----
                  # 单组变量的盒子 --中间粗线为中位数,盒子上下边缘是3/4和1/4分位数，两条触须线延伸到取值区域的边缘
                      with(d.cancer, boxplot(v0))
                      boxplot(d.dancer$v0)
                  # 盒形图比较两组或多组,纵轴变量~横轴变量
                      with(d.cancer,boxplot(v0~sex))
                      boxplot(d.cancer$v0,d.cancer$sex)
                  # 画若干个变量的并排盒形图
                      with(d.cancer,
                           boxplot(list('疗前'=v0, '疗后'=v1)))
                      boxplot(list('money'=data1$money,'value'=data1$value))
                         
       #### 正态QQ图 ####
            # 当变量样本来自正态分布总体时， 正态QQ图的散点近似在一条直线周围
                      qqnorm(x)
                      qqline(x, lwd=2, col='blue')
                  
       #### 散点图 plot ####
            ---- ----
                        plot(d.class$height, d.class$weight,main ='a',xlab='1',ylab='g',pch=12,col='blue',cex=2)
                        with(d.class,plot(height, weight,pch=16, col='blue',cex=2))
                  # main标题,xlab，ylab横纵坐标标题,pch散点形状,col散点颜色,cex散点大小
                        with(d.class, plot(height, weight,pch=16, col='blue',cex=1 + (age - min(age))/(max(age)-min(age))))
                  # 气泡大小表示第三维 cex  
                        with(d.class, plot(height, weight,pch=16, col=ifelse(sex=='M', 'blue', 'red'),cex=1 + (age - min(age))/(max(age)-min(age))))              # clo=ifelse(xxx==,'blue','red) 颜色区分性别,cex是气泡大小表现年龄
                        pairs(d.class[, c('age', 'height', 'weight')])
                  # paris 做散点图矩阵
                        library(ggpubr)
                        show_point_shapes()
                  # 查看散点形状
                        
                        
       #### 曲线图 curve ####
            ---- ----
                          curve(1-3*x-x^2,-4,2)        curve(sin,-pi,pi)
                  # curve 函数接受一个函数,或者以x为变量的表达式,以及自变量的区间
                        x <- seq(0, 2*pi, length=200)
                        y <- sin(x)
                        plot(x,y, type='l')
                  # plot函数中,使用type='1'参数可以作曲线图 length=200 *尚不清楚
                        plot(x,y, type='l', lwd=2, lty=3)
                  # lwd可指定线宽度,lty可指定虚线
                        library(ggpubr)
                        show_line_types() 
                  # 显示线条类型(ggpubr包内的函数） lty='twodash'
                        x <- seq(0, 2*pi, length=200)
                        y1 <- sin(x)
                        y2 <- cos(x)
                        matplot(x, cbind(y1, y2), type='l', 
                                lty=1, lwd=2, col=c("red", "blue"),
                                xlab="x", ylab="")
                        abline(h=0, col='gray')
                  # 多条曲线,可以用matplot
       #### 三维图 ####
             ----静态----
               # persp 三维曲面图,contour等值线图,  image色块图. x,y构成一张平面网络,z即为包含z坐标的矩阵,每行对应一个横坐标,每列对应一个纵坐标
                        x <- seq(-3,3, length=100)
                        y <- x
                        f <- function(x,y,ssq1=1, ssq2=2, rho=0.5){
                          det1 <- ssq1*ssq2*(1 - rho^2)
                          s1 <- sqrt(ssq1)
                          s2 <- sqrt(ssq2)
                          1/(2*pi*sqrt(det1)) * exp(-0.5 / det1 * (
                            ssq2*x^2 + ssq1*y^2 - 2*rho*s1*s2*x*y))
                        }
                        z <- outer(x, y, f)     # outer中的f即为一个自定义的函数,该函数与x,y有关
                # 生成二元正态分布密度曲线数据
                        persp(x, y, z)    # 三维曲面图
                        contour(x, y, z)  # 等值线图
                        image(x, y, z)    # 色块图
              ---动态---
                        library(rgl)
                # rgl包能制作动态的三维散点图与曲线图
                        with(iris, plot3d(
                        Sepal.Length, Sepal.Width, Petal.Length, 
                        type="s", col=as.numeric(Species)))
                # 可拖动旋转,type='s'表示绘点符号是球体,还可选"p"(点),"l"(连线),"h"(向z=0连线),还可用size=指定大小倍数(缺省值为3) 
                        x <- seq(-3,3, length=100)
                        y <- x
                        f <- function(x,y,ssq1=1, ssq2=2, rho=0.5){
                          det1 <- ssq1*ssq2*(1 - rho^2)
                          s1 <- sqrt(ssq1)
                          s2 <- sqrt(ssq2)
                          1/(2*pi*sqrt(det1)) * exp(-0.5 / det1 * (
                            ssq2*x^2 + ssq1*y^2 - 2*rho*s1*s2*x*y))
                        }
                        z <- outer(x, y, f)
                        persp3d(x=x, y=y, z=z, col='red')
                # 用rgl的persp3d()函数作曲面图。 如 二元正态分布密度曲面
                        
                       
       #### 低级图形函数 ####
            ----abline----
                        with(d.class, plot(height, weight))
                        abline(-143, 3.9, col="red", lwd=2)
                        abline(v=c(55,60,65,70), col="gray")
                        abline(h=c(60,80,100,120,140), col="gray")
                # 用abline函数在图中增加直线 a,b 指定截距和斜率 
                # v为竖线指定坐标,h为水平线指定纵
            ----points----
                        x <- seq(0, 2*pi, length=200)
                        y <- sin(x)
                        special <- list(x=(0:4)*pi/2, y=sin((0:4)*pi/2))
                        plot(x, y, type='l')
                        points(special$x, special$y, 
                               col="red", pch=16, cex=2)
                        points(special, col="red", pch=16, cex=2)
                # 用points函数增加散点
            ----lines----
                        x <- seq(0, 2*pi, length=200)
                        y1 <- sin(x)
                        y2 <- cos(x)
                        plot(x, y1, type='l', lwd=2, col="red")
                        lines(x, y2, lwd=2, col="blue")
                        abline(h=0, col='gray')
                # 用lines函数增加曲线
            ----图例----
                        x <- seq(0, 2*pi, length=200)
                        y1 <- sin(x)
                        y2 <- cos(x)
                        plot(x, y1, type='l', lwd=2, col="red")
                        lines(x, y2, lwd=2, col="blue")
                        abline(h=0, col='gray')
                        legend(0, -0.5, col=c("red", "blue"),
                               lty=c(1,1), lwd=c(2,2), 
                               legend=c("sin", "cos"))
                # 用legend函数增加图例
            ----axis()----
                        x <- c('一月'=15, '二月'=20, 
                                 '三月'=18, '四月'=22)
                        plot(seq(along=x), x, axes=FALSE,
                                type='b', lwd=3,
                                main='前四个月销售额',
                                xlab='', ylab='销售额') 
                        box();axis(2)
                # axes=FALSE,即取消自动的坐标轴
                # box画边框,axis(),1,2,3,4分表代表横轴,纵轴,上方,右方 at为刻度线位置
                        x <- seq(0, 2*pi, length=200)
                        y1 <- sin(x)
                        plot(x, y1, type='l', lwd=2,
                             axes=FALSE,
                             xlab='x', ylab='')
                        abline(h=0, col='gray')
                        box()
                        axis(2)
                        axis(1, at=(0:4)/2*pi,
                             labels=c('0', 'pi/2', 'pi', '3pi/2', '2pi'))
              # 不使用数学符号,表示为pi/2
                        x <- seq(0, 2*pi, length=200)
                        y1 <- sin(x)
                        plot(x, y1, type='l', lwd=2,
                             axes=FALSE,
                             xlab='x', ylab='')
                        abline(h=0, col='gray')
                        box()
                        axis(2)
                        axis(1, at=(0:4)/2*pi,
                             labels=c(0, expression(pi/2), 
                                      expression(pi), expression(3*pi/2), 
                                      expression(2*pi)))
              # 使用数学符号,表示为Π/2
        ----text---
                        with(d.class, plot(height, weight))
                        lm1 <- lm(weight ~ height, data=d.class)
                        abline(lm1, col='red', lwd=2)
                        a <- coef(lm1)[1]
                        b <- coef(lm1)[2]
                        text(52, 145, adj=0, '线性回归:')
                        text(52, 140, adj=0,
                             substitute(hat(y) == a + b*x,
                                        list(a=round(coef(lm1)[1], 2), 
                                             b=round(coef(lm1)[2], 2))))
              # text()在坐标区域内添加文字。 mtext()在边空处添加文字
        ----locator()和identify()----
                        x <- seq(0, 2*pi, length=200)
                        y1 <- sin(x); y2 <- cos(x)
                        plot(x, y1, type='l',
                             col="red")
                        lines(x, y2, col="blue")
                        legend(locator(1), col=c("red", "blue"),
                               lty=c(1,1), legend=c("sin", "cos"))  
              # 即鼠标点一个点,点击完成后,该点附近有图例
                        identify(x, y, labels)
              # 可以识别点击处的点并标注标签
        
       #### 图形参数 ####
                # par()参数指定图形参数并返回原来的参数值--一张图可放几个
                        opar <- par(mfrow=c(2,2))
                        with(d.class, {hist(height);
                              boxplot(height);
                              qqnorm(height); qqline(height);
                              plot(height); rug(height,side=2)})
                # 将图形参数返回为原来的参数         
                        par(opar)
                # 在函数内，可以在函数开头修改了图形参数后， 用on.exit()函数将恢复原始图形参数作为函数退出前必须完成的任务
                        f <- function(){
                          opar <- par(mfrow=c(2,2)); on.exit(par(opar))
                          with(
                            d.class,
                            {hist(height);
                              boxplot(height);
                              qqnorm(height); qqline(height);
                              plot(height); rug(height,side=2)
                            })
                        }
                        f()
                        
            ----图形元素控制----
                        # pch=16参数。散点符号，取的数。
                        
                        # lty=2参数。线型，1为实线，从2开始为各种虚线。
                        
                        # lwd=2参数，线的粗细，标准粗细为1。
                        
                        # col="red"参数，颜色，可以是数字， 或颜色名字符串如"red"，"blue"等。 用colors()函数查询有名字的颜色。 用rainbow(n)函数产生连续变化的颜色。
                        
                        # font=2参数，字体，一般font=1是正体,2是粗体, 3是斜体,4是粗斜体。
                        
                        # adj=-0.1指定文本相对于给定坐标的对齐方式。 取0表示左对齐,取1表示右对齐,取0.5表示居中。 此参数的值实际代表的是出现在给定坐标左边的文本的比例。
                        
                        # cex=1.5 绘点符号大小倍数，基本值为1。
            ----坐标轴与坐标刻度----
                        # mgp=c(3,1,0) 坐标轴的标签、刻度值、坐标轴线 到实际的坐标轴位置的距离
                        # lab=c(5,7,12),第一个数为x轴刻度线个数， 第二个数为y轴刻度线个数， 第三个数是坐标刻度标签的字符宽度
                        # las=1 坐标刻度标签的方向。 0表示总是平行于坐标轴, 1表示总是水平, 2表示总是垂直于坐标轴
                        # tck=0.01 坐标轴刻度线长度，以绘图区域大小为单位1
                        # xaxs="s", yaxs="e": 控制x轴和y轴标刻度的方法，“i”使得刻度线都落在数据范围内部,而"r"方式所留的边空较小
            ----图形边空----
                      
                              opar <- par(mar=c(2,2,0.5,0.5), 
                                          mgp=c(0.5, 0.5, 0), tck=0.005)
                              with(d.class, plot(height, weight, 
                                               xlab='', ylab=''))
                        # mar参数控制下左上右,
                              par(opar)
                        # 返回原来的参数
            ----一页多图----
                              opar <- par(mfrow=c(2,2),
                                            oma=c(0,0,2,0))   # oma指定四个外边空的行数
                              with(d.class, {hist(height);  
                                boxplot(height);
                                qqnorm(height); qqline(height);
                                plot(height); rug(height,side=2)})
                              mtext(side=3, text='身高分布', cex=2, outer=T) # 用mtext加outer=T指定在外边空添加文本
                              par(opar)
                              # 返回原来参数设置
                            
 
                              
                              
                              
                              
                              
#### ggplot作图 ####
       #### 指导思想 ####
                    # 统计图形应该用尽可能少的图形元素表示尽可能多的数据
                    # 品味+数据+感知(颜色、三维形状、坐标轴范围、宽高比)
                    
       #### 流程大致模板 ####
                              p <- ggplot(data=<输入数据框>,
                                          mapping=aes(<维度>=<变量名>,
                                                      <维度>=<变量名>, <...>)) 
                  # 指定参与作图的每个变量分别映射到哪些图形特性,比如映射为x坐标,y坐标,颜色,形状
                              p + geom_<图形类型>(<...>) + 
                                scale_<映射>_<类型>(<...>) +  # 设立适当坐标系统
                                coord_<类型>(<...>) +         # 设立适当坐标系统
                                labs(<...>)                   # 设定标题和图例位置
                              
                        
     
                              
       #### 散点图 ####
        ----作图----
                              library(tidyverse)
                              p <- ggplot(data = gapminder,
                                          mapping = aes(
                                            x = gdpPercap,
                                            y = lifeExp))                     # 人均GDP映射到x轴,期望寿命映射到y轴
                              p <- ggplot(gapminder, aes(gdpPercap, lifeExp)) # 简略写法
                      # 指定数据和映射
                              p + geom_point()            # 散点
                      # 使用geom_xxx()指定一个图形类型
                              p + geom_smooth()           # 拟合曲线
                      # 用相同的映射做出拟合的曲线图
                              p + geom_point() + geom_smooth(method="lm")  
                      # 可以用geom_smooth()的参数选择不同的拟合方法， 如直线拟合(lm),局部多项式曲线拟合(loess)
                              p + geom_point() +
                                geom_smooth(method="gam") +
                                scale_x_log10()
                      # x轴变量（人均GDP）分布非正态，严重右偏， 使得大多数散点重叠地分布在直角坐标系的左下角。 将x轴用对数刻度可以改善， 函数为scale_x_log10()
                              p + geom_point() +
                                +     geom_smooth(method="gam") +
                                +     scale_x_log10(labels=scales::dollar)
                      # scale_xxx()的labels选项指定如何标出坐标刻度数字
                              
        ----颜色,符号,线型等映射----
                      # 将观测变量continent变量映射到color
                              p <- ggplot(data=gapminder,
                                            mapping = aes(
                                              x = gdpPercap,
                                              y = lifeExp,
                                              color = continent))  # 自动生成图例
                      # 将color和fill都指定为变量 continent --  置信区间颜色也用不同大洲区分
                              p <- ggplot(data=gapminder,
                                          mapping = aes(           # aes()仅用来指定变量与图形元素类型的映射
                                            x = gdpPercap,
                                            y = lifeExp,
                                            color = continent,
                                            fill = continent))     # 自动生成图例
                              p + geom_point(color="chartreuse4") +
                                  geom_smooth(method="loess") +
                                  scale_x_log10(labels=scales::dollar)   #  为了指定固定颜色， 应将color=作为geom_xxx()函数的选项
                      # 关于颜色,透明度,符号,线型的设置参数
                              p + geom_point(alpha=0.5) +
                                geom_smooth(method="lm", color="cadetblue1", se = FALSE, size = 4, alpha = 0.3) +
                                                    # se = FALSE 关闭置信空间显示,alpha= ,设置了透明度(取0~1),size指定线的粗细
                                scale_x_log10(labels=scales::dollar)
                      # labs()函数加上标题
                              p + geom_point(alpha = 0.3) +
                                geom_smooth(method="gam") +
                                scale_x_log10(labels=scales::dollar) + 
                                labs(
                                  x = "人均GDP",
                                  y = "期望寿命（年数）",
                                  title = "经济增长与期望寿命",
                                  subtitle = "数据点为每个国家每年",
                                  caption = "数据来源: gapminder"  )    #  caption即为右下方标注
        ----在geom函数中映射变量----
                      # 单独在geom_point中用mapping = aes(<...>)单独指定变量映射,ggplot中mapping设置使得后面的曲线都会分组呈现
                      # 而geom_point中单独设置,可以只让point分组,其他仍然默认一条
                              p <- ggplot(data=gapminder,
                                            mapping = aes(
                                              x = gdpPercap,
                                              y = lifeExp))
                              p + geom_point(mapping = aes(color = continent)) +
                                geom_smooth(method="loess") +
                                scale_x_log10(labels=scales::dollar)
                     # 将一个分类变量映射到不同绘图符号
                              p <- ggplot(data = filter(gapminder, year == 2007),
                                          mapping = aes(
                                            x = gdpPercap,
                                            y = lifeExp, 
                                            shape = continent))
                              p + geom_point(alpha = 0.4, size = 4) +        # 所有点使用的符号设置可以单独在geom_point中设置
                                scale_x_log10(labels=scales::dollar)
                     #  绘图时参与映射的分类变量会自动产生分类效果
                     #  color映射与fill映射到分类变量时常常会起到与添加group维相同的作用
                     #  需要分组时还应该显式地映射group维
        ----连续变量的颜色映射----
                     #  连续变量映射为渐变色        
                              p <- ggplot(data=gapminder,
                                            mapping = aes(
                                              x = gdpPercap,
                                              y = lifeExp,
                                              color = log(pop)))             # 将人口数取自然对数映射为渐变色
                              p + geom_point() +
                                geom_smooth(method="loess") +
                                scale_x_log10(labels=scales::dollar)
                              
       #### 折线图-分组-切片 ####
            ----图形中的分组和折线图----
                    # 增加group分组映射
                              p <- ggplot(data = gapminder,
                                          mapping = aes(
                                            x = year, 
                                            y = lifeExp,
                                            group = country))
                              p + geom_line()
                    # 用geom_area()作折线图,并填充颜色
                              p <- ggplot(data = filter(gapminder, country == "Rwanda"),
                                          mapping = aes(
                                            x = year, 
                                            y = lifeExp))
                              p + geom_area(fill = "darkseagreen1", alpha = 0.5)   
                    # 图形的纵坐标应该从0开始， 使得阴影部分的大小与纵坐标值成比例
            ----切片facet----
                    # 将一个作图区域拆分成若干个小块,称为切片或分面           
                              p <- ggplot(data = gapminder,
                                            mapping = aes(
                                              x = year, 
                                              y = lifeExp,
                                              group = country))
                              p + geom_line() + facet_wrap(~ continent, nrow= ,ncol=)
                              # 切片是一种图形摆放方法,  用facet_wrap()函数来规定,nrow和ncol决定图形摆放的行列数
                    # 按照一个或两个分类变量的不同值将数据分为若干个子集,每个数据子集分别在切片上作图
                              p <- ggplot(data = gapminder,
                                          mapping = aes(
                                            x = year, 
                                            y = lifeExp))
                              p + geom_line(mapping = aes(group = country), color = "gray70") +   
                              # group转到了geom_line中,即拟合线按照国家分组,而不是按照大洲
                                geom_smooth(method = "loess", color="cyan", se = FALSE, size = 1.1) +
                              # 此处因为group放到了geom_line中,geom_smooth中没有使用group维,则每幅切片之中仅有一条拟合线
                                facet_wrap(~ continent, ncol = 2) +
                                labs(
                                  x = "年份",
                                  y = "期望寿命",
                                  title = "五个大洲各国期望寿命变化趋势"
                                )
                              # 设置标题和坐标轴标签
                     # facet_grid()按照两个分类变量交叉分组分配切片
                              p <- ggplot(data=gss_sm,
                                          mapping = aes(
                                            x = age,
                                            y = childs))
                              p + geom_point(alpha = 0.2)
                              # 未交叉分配前
                              p + geom_point(alpha = 0.2) +
                                facet_grid(sex ~ race) # sex~race使得不同性别对应到不同行,不同种族对应到不同列
                              # 交叉分配后
                              
       #### 数据变换与条形图 ####
                        # geom_bar
                              p <- ggplot(data = gss_sm,
                                          mapping = aes(x = bigregion))
                              p + geom_bar()       
                        # 预先统计好频数
                              df1 <- gss_sm %>%
                                select(bigregion) %>%
                                count(bigregion) %>%
                                mutate(ratio = n / sum(n))
                              
                              p <- ggplot(data = df1,
                                          mapping = aes(x = bigregion, y = n))
                              p + geom_col() + 
                                labs(y = "Count")
                        # x轴文字标签旋转45度角
                              p <- ggplot(data = df1,
                                          mapping = aes(x = bigregion, y = ratio))
                              p + geom_col() + 
                                labs(y = "Ratio") +
                              theme(
                                axis.text.x = element_text(
                                  angle = 45, vjust = 1, hjust = 1)  )
                        # 纵向条形图改为横向条形图
                              p <- ggplot(data = df1,
                                          mapping = aes(x = bigregion, y = ratio))
                              p + geom_col() + 
                                labs(y = "Ratio") +
                                coord_flip() + 
                           -- 横向改为纵向的关键代码
                                theme(plot.title = element_text(vjust = -0.1,hjust = 2.0)) 
                           -- hjust 主标题的居中位置调整参数
                           -- vjust 主标题的上下位置调整参数      
                              
                              
#### 颜色 ####
       #### 
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
#### 自带数据框 ####
                    iris  ----
                    library(gapminder)
                    head(gapminder, 20) ----     # 1704*6
                      install.packages("devtools")
                      devtools::install_github("kjhealy/socviz")
                    library(socviz)
                    head(gss_sm, 2)     ----     # 2867*32 社会调查变量主要取属性值 如无序分类、有序分类、分组的数值、整数值
                    
                      
                              
#### 其他 ####
                    # 关闭小键盘之后按一下”0“则会改变光标
                              
                              
                      
                      
                      
                      
                    
                    
                    
                    
                    
                    
                    