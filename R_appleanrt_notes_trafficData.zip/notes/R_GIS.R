---- R_GIS ----
#### 基本概念 ####
    #### 地理信息系统基础知识 ####
      # 空间数据   表示为矢量或栅格数据
      # 矢量数据   表示世界的对象视图，由点、线和多边形组成 - 每个空间对象（例如点、线或多边形）都可以与无限数量的属性相关联
      # 栅格数据表示世界的野外视图，由格网组成,栅格数据具有分配给每个像元的一个数值
      # 所有空间数据都需要具有地理坐标系 （GCS） 和地图投影

    #### GIS+基准面+PIS--区别 ####
          # GIS         地理坐标系 定义地球模型上要素的参考框架,形状--球形，单位--度 ，---知道一点在地图上的确切数据
          # PCS         平坦,包含GCS,使用数学（投影算法）和其他参数将该GCS转换为平面, 单位--米 --- 绘制平面地图数据
          
          # 基准面      GIS的一个参数,用于确定使用哪个模型（椭球体）来表示地球表面以及地球相对于表面的位置,地球表面不是完全光滑或圆形的为世界不同地区设计了许多不同的基准面
          # 除基准面外，GCS 还包括本初子午线（指定 0° 经度的位置）和角度单位（通常为度）
          
          # 投影        是投影坐标系 （PCS） 中的一个参数,定义如何在平面地图上呈现圆形地球的数学算法
          # PCS         是特定圆形地球模型如何投影到平面地图上的完整定义, 除投影外，PCS 还包括地理坐标系（用于定义地球模型）、单位（通常为米）和一组参数值，这些参数值因投影而异（东偏移量、中央经线、标准纬线等）
          
          # WKT         已知文本 （WKT） 是定义坐标系所有必要参数的字符串。保存任何坐标系的投影文件 （.prj），然后在文本编辑器中将其打开以查看其 WKT
          # WKID        （WKID） 是分配给坐标系的唯一编号
    #### 使用R的地理矢量和栅格数据 ####
         #### 矢量数据 ####
                   #### 点(向量) ####
          
                      ---- 单个点 ----
                                  a_single_point <- st_point(x = c(1,3)) # a single point with XY coordinates of 1,3 in unspecified coordinate system
                                  a_single_point # view the content of the object
                                  attributes(a_single_point) #view the different components of an sfg object
                      ---- 有五个点的对象 ----
                                  #create five sfg point objects
                                  point1 <- st_point(x = c(1,3)) 
                                  point2 <- st_point(x = c(2, 4))
                                  point3 <- st_point(x = c(3, 3))
                                  point4 <- st_point(x = c(4, 3))
                                  point5 <- st_point(x = c(5, 2))
                                  
                                  points <- st_sfc(point1,point2,point3,point4,point5) # create a single sfc points object
                                  
                                  points
                      ---- 设置CRS(坐标参考系) ----
                                  points_wgs <- st_sfc(point1,point2,point3,point4,point5,crs=4326) # create a single sfc points object, and define the CRS
                                  
                                  points_wgs
                      ---- 绘制点数据 ----
                                  plot(points_wgs,col="red",pch=16) # map the sfc object using the plot function
                      ---- 创建数据帧 ----
                                  points_attribute_data <- data.frame(transport_mode = c("Bicycle","Pedestrian","Motor Vehicle","Motor Vehicle","Motor Vehicle"))
                                  
                                  points_attribute_data
                                  
                      ---- 将属性数据与空间点数据关联 ---- 
                                  points_sf <- st_sf(points_attribute_data,geometry=points)
                                  
                                  points_sf
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          
                   #### 线(矩阵) ####
                         ---- 定义线的节点并按行附加得到表示单行的矩阵 ----
                                  a_single_line_matrix <- rbind(c(1,1), 
                                                                c(2, 4), 
                                                                c(3, 3), 
                                                                c(4, 3), 
                                                                c(5,2))# create a matrix with 
                                  
                                  a_single_line_matrix
                                  
                                  a_single_line <-  st_linestring(a_single_line_matrix)
                                  a_single_line
                                  # 矩阵创建单个线
                                  attributes(a_single_line)
                                  # 查看属性
                                  plot(a_single_line,col="darkblue")
                                  # 绘图
                             # 创建多个线串对象
                                  line1 <- st_linestring(rbind(c(1,1), 
                                                               c(2,4), 
                                                               c(3,3), 
                                                               c(4,3), 
                                                               c(5,2)))
                                  line2 <- st_linestring(rbind(c(3,3), 
                                                               c(3,5), 
                                                               c(4,5)))
                                  line3 <- st_linestring(rbind(c(2,4), 
                                                               c(-1,4), 
                                                               c(-2,-2)))
                           
                                  lines <- st_sfc(line1,line2,line3,crs=4326)
                                  # WGS 4326 对应的CRS代码1984创建一个包含关联CRS信息的对象
                                  lines
                             # 创建属性表 -- 每条线代表不同的路段,每条路段都有不同的名称和限速
                                  line_attribute_data <- data.frame(road_name = c("Vinmore Avenue","Williams Road","Empress Avenue"), 
                                                                    speed_limit = c(30,50,40))
                                  # 创建属性表 -- 每条线代表不同的路段,每条路段都有不同的名称和限速
                                  line_attribute_data
                                  # 将几何属性附加到属性表
                                  lines_sf <- st_sf(line_attribute_data,geometry=lines)
                                  
                                  lines_sf
                                  plot(lines_sf)
                                  # 绘图,自动映射每个段的属性
                                  plot(lines_sf[1])
                                  plot(lines_sf["speed_limit"])
                                  # 想映射一个特定的属性，我们需要使用符号来指定它：plot()sfLINESTRING[]
                                  
                                 
                                  
                                  
                                  
                                  
                                  
                   #### 多边形(列表) ####
                            # 创建多边形 
                                  a_polygon_vertices_matrix <- rbind(c(1,1), c(2, 4), c(3, 3), c(4, 3), c(5,2),c(1,1))
                                  a_polygon_list = list(a_polygon_vertices_matrix)
                                  a_polygon_list
                                  # 矩阵 -> 列表
                                  a_polygon <-  st_polygon(a_polygon_list)
                                  plot(a_polygon,col="forestgreen")
                                  # 调用st_polygon 函数,绘制多边形
                                  lake_vertices_matrix <- rbind(c(1.5, 1.5),c(1.5,1.75),c(1.75,1.75),c(1.75,1.5),c(1.5,1.5))
                                  lake_vertices_matrix
                                  
                                  a_single_polygon_with_a_hole_list = list(a_polygon_vertices_matrix,lake_vertices_matrix)
                                  a_single_polygon_with_a_hole_list
                                  # 创建一个顶点在森林中多边形湖泊,并希望删掉
                                  a_single_polygon_with_a_hole <-  st_polygon(a_single_polygon_with_a_hole_list)
                                  plot(a_single_polygon_with_a_hole,col="forestgreen")
                             # 创建一个具有多个多边形,属性信息和定义的GRS的对象
                                  park1 <- a_single_polygon_with_a_hole
                                  park2 <- st_polygon(list(
                                    rbind(
                                      c(6,6),c(8,7),c(11,9), c(10,6),c(8,5),c(6,6)
                                    )
                                  ))
                                  park_attributes <- data.frame(park_name = c("Gilmore","Dixon"))
                                  parks_sf <- st_sf(park_attributes, geometry = st_sfc(park1,park2,crs=4326))
                                  plot(parks_sf)
                              # sfg对象是指调用st_polygon,st_point,st_linestring创建的对象
                              # st对象是指附加属性,调用st_sf创建的st
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
         #### 光栅(栅格数据) ####
                   #### 基础概念 ####
                        # 栅格数据由具有等间距像元的格网组成，这些像元覆盖地球表面上的一定范围
                        # 每个单元格可以存储一个数值，该数值可以对应于任何可测量量，包括分类和数字概念
                        # 栅格数据可用于表示土地覆被类型（森林、建成区或湿地等类别）或年平均降水量
                        # 键参数是其空间分辨率,即格网像元的大小,空间分辨率越高，表示像元越小
                                  
                   #### 浏览光栅数据并创建实例  ####
                            # 创建对象-矩形网格像元-大小:10m*10m      
                                  van_raster <- raster(resolution=1000, #specify spatial resolution
                                                       # 网格分辨率为10000平方米(100*100网格单元)
                                                       xmn=483691, xmx=498329, #specify extent from east to west in metres
                                                       ymn=5449535, ymx=5462381, #specify extent from north to south in metres
                                                       crs=26910) #set projection
                                  van_raster
                            # 关键组件-网格单元的值
                                  values(van_raster)
                            # 对象中的每一个网格单元都可以存储一个数值,该数值对应于其边界内发生的某种空间现象
                                  number_cells <- ncell(van_raster) #the number of grid cells in the RasterLayer object
                                  number_cells
                                  # RasterLayer 对象中的网格单元数目
                                  cell_values <- runif(number_cells,min = -1,max=1)
                                  cell_values
                                  # (0,1)均匀分布随机填充
                                  values(van_raster) <- cell_values # assign each cell a value from the random generation
                                  plot(van_raster)
                   #### 读取空间数据 ####
                                # 以坐标作为点数据的表格数据读取,以及ESRI形状文件
                        #### 带有XY坐标的表格数据 ####
                                  icbc_crash <- read.csv("D:/Edge_downloads/R_GIS1/ICBC_cyclist_crashes.csv") # use the file location of where you have stored your data
                                  str(icbc_crash)
                                  #look at data frame
                                  is.na(icbc_crash$Latitude) %>% summary() #check for missing values in latitude
                                  is.na(icbc_crash$Longitude) %>% summary() #check for missing values in longitude
                                  icbc_crash <- icbc_crash %>% 
                                    dplyr::filter(!is.na(Latitude)) 
                                  # remove the records which have missing values
                                  is.na(icbc_crash$Latitude) %>% summary()
                                  is.na(icbc_crash$Longitude) %>% summary()
                            # 输入:1数据框 2将经度和纬度坐标表示为R向量的别名 3坐标系信息
                                  icbc_crash_sf <- st_as_sf(icbc_crash, coords = c("Longitude","Latitude"), crs = 4326)
                                  # 经度为x坐标,纬度为y坐标
                                  str(icbc_crash_sf)
                                  plot(icbc_crash_sf["Cyclist.Flag"])
                                  
                            # 将这些数据转换为投影坐标系--使用包中的函数来尝试为我们的数据找出正确的函数
                                  library(crsuggest)
                                  possible_crs <- suggest_crs(icbc_crash_sf,units = "m",limit = 20)
                                  
                                  possible_crs #View the the top 10 suggestions
                                  # 选择投影后,用函数将数据“转换”到坐标系中,并指定与该坐标系关联的EPSG代码
                                  icbc_crash_sf_proj <- st_transform(icbc_crash_sf,crs=3005)
                                  # 使用st_transform() sf st_crs() 检查对象的CRS信息
                                  st_crs(icbc_crash_sf_proj)
                                  
                                  icbc_crash_van <- icbc_crash_sf %>% 
                                    dplyr::filter(Municipality Name =="VANCOUVER")
                                    plot(icbc_crash_van["Cyclist.Flag"])
                                  # 基于列的数据查询隔离温哥华的记录--绘制数据地图
                                  possible_crs_van <- suggest_crs(icbc_crash_van)
                                  possible_crs_van
                                  
                                  icbc_crash_van_proj <- st_transform(icbc_crash_van,crs=26910)
                                  # 选择 NAD83 / UTM 区域 10N 并将其转换为此投影
                                  plot(icbc_crash_van_proj["Cyclist.Flag"])
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                        #### 形状文件 ####
                                  van_boundary <- read_sf("D:/Edge_downloads/R_GIS1/CoV_boundary.shp") 
                                  van_boundary
                                  # 加载shapefile时,始终指向.shp文件,将自动从其他文件加载信息，
                                  # 包括属性数据 （.dbf）、坐标系信息 （.prj） 和几何信息（.shp 和 .shx）,并将它们直接组合到一个对象中
                                  plot(van_boundary["Type"])
                                  
                        #### 以编程方式 ####
                            ---- 专门设计用于从特定位置检索数据的包 ----
                                     osmdata：从OpenStreetMaps检索各种建筑环境数据
                                     cancensus：从加拿大统计局检索汇总到人口普查地理区域的国家人口普查数据
                            ---- 开放街道地图 ----
                                       van_bb <- getbb("Vancouver BC")
                                     # getbb() 接受一个字符串并返回感兴趣区域的矩形边界框
                                       van_bb 
                            ---- 加拿大人口普查地理 ----
                                         
                   #### GIS分析工具包 ####
                        #### 属性查询 ####
                                       library(cancensus)
                                       find_census_vectors("Median total income",type = "total", dataset = "CA16",query_type = "semantic")                                        #options(cancensus.api_key = "your_api_key") 
                                       # uncomment and input your API Key here to enable retrieval of data from Statistics Canada
                                       mv_census <- get_census(dataset='CA16', 
                                                               #specify the census of interest
                                                               regions=list(CSD="5915"),#specify the region of interest
                                                               vectors=c("v_CA16_2397"), # specify the attribute data of interest
                                                               labels = "short",
                                                               # here we specify short variabhle names, otherwise they get very long
                                                               level='DA', #specify the census geography
                                                               geo_format = "sf", #specify the geographic data format as output
                                                               quiet = TRUE 
                                                               #turn off download progress messages (set to FALSE to see messages)
                                                               
                                       )
                                       
                                       
                                       mv_census