# 读取数据 ####
  data <- read.csv("D:/documents/code_note/yunchou/bian.csv")
  point_number <- max(data$head,data$tail) 
  bian_number <- nrow(data)
  
  # 构造邻接矩阵
  lj_matrix <- matrix(0,point_number,point_number)
  for (i in 1:bian_number) {
     head_point  <- data[i,'head']
     tail_point <- data[i,'tail']
     lj_matrix[head_point,tail_point] <- data[i,'length']
  }
  # 创建边的编号矩阵
  edge_matrix <- matrix(0,point_number,point_number)
  for (i in 1:bian_number) {
    a <- data[i,'head']
    b <- data[i,'tail']
    edge_matrix[a,b] <- data[i,'number']
    }
  
# Floyd求解 ####
  floyd<-function(A){
    A[A==0] <- Inf
    diag(A) <- 0
    n<-nrow(A)
    D<-A
    path<-matrix(0,n,n)
    for(i in 1:n){
      for(j in 1:n){
        if(is.finite(D[i,j])==T){path[i,j]=j}
      }
    }
    for(k in 1:n){
      for(i in 1:n){
        for(j in 1:n){
          if(D[i,k]+D[k,j]<D[i,j]){
            D[i,j]=D[i,k]+D[k,j];
            path[i,j]=path[i,k]
          }
        }
      }
    }
    return(list(D=D,path=path))
  }
  # 求解各顶点间最短距离
  result <- floyd(lj_matrix)
  distance <- as.data.frame(result$D)
  m_distance <- result$D
  path <- as.data.frame(result$path)
  m_path <- result$path
# 顶点对间####

  # 绘制热力图
  library(reshape2)
  library(ggplot2)
  reli <- function(matrix,titlename){
    melted_cormat <- melt(matrix)
    
    ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
      geom_tile(color = "white")+
      scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                           midpoint = 0,  space = "Lab", limits = c(0, 51),
                           name="最短距离") +
      theme_minimal()+ # minimal theme
      theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                       size = 6, hjust = 1))+
      coord_fixed() +
      geom_text(aes(Var2, Var1, label = value), color = "black", size = 2)+
      scale_x_continuous(breaks = seq(0, point_number, by = 1)) +
      scale_y_continuous(breaks = seq(0, point_number, by = 1)) +
      ggtitle(titlename)+
      theme(plot.title = element_text(hjust = 0.5, vjust = 0.5,size = 16,face = 'bold'),axis.title.x=element_text(vjust=1, size=1,face = "bold"))
    # Print the heatmap
    print(ggheatmap)
  }
  reli(m_distance,'各顶点间最短距离')
  
# 最短路均值####
  t_distance <- t(distance)
  point_shortest <- data.frame(matrix(nrow = point_number, ncol = 2))
  colnames(point_shortest) <- c('point','shortest')
  point_shortest$point <- c(1:point_number)
  for (i in 1:point_number) {
    point_shortest[i,'shortest'] <- round(sum(distance[,i])/(point_number-1),2)
  }  
  point_shortest <- point_shortest[order(point_shortest$shortest),]
  
  point_shortest$group <- 'grey'
  point_shortest[c(1:3),'group'] <- 'lightgreen'
  point_number2 <- point_number-2
  point_shortest[c(point_number2:point_number),'group'] <- "#FF9200FF"
  p <- ggplot(point_shortest,aes(x=point,y=shortest)) + geom_col(fill=point_shortest$group) +  ggtitle("各点到其他顶点的平均最短路长度") + scale_x_continuous(breaks = seq(1, point_number, by = 1)) + theme(plot.title = element_text(hjust = 0.5, vjust = 0.5,size = 16,face = 'bold')) + geom_text(aes(label = shortest), position = position_nudge(y = 0.2),size=3.9)+   coord_flip()
  print(p)
  sd(point_shortest$shortest)
  
  
# 最短路径经过边####
 edge_used <- function(D,path,edge_id){
   # 假设已经得到path和D矩阵
   n <- nrow(D)
   
   # 初始化边的经过次数矩阵
   edge_counts <- matrix(0, nrow=n, ncol=n)
   
   # 遍历每个节点对之间的最短路径
   for (i in 1:n) {
     for (j in 1:n) {
       if (i != j) {
         # 获取i到j的最短路径
         path_nodes <- c(i, path[i,j], j) 
         for (k in 1:(length(path_nodes)-1)) {
           # 将该边在经过路径上的计数加1
           start_node <- path_nodes[k]
           end_node <- path_nodes[k+1]
           edge_counts[start_node, end_node] <- edge_counts[start_node, end_node] + 1
         }
       }
     }
   }
     bian <- c()
     counts <- c()
     for (i in 1:nrow(edge_id)) {
       for (j in 1:nrow(edge_id)) {
         if(edge_id[i,j]!=0){
           bian <- append(bian,edge_id[i,j])
           counts <- append(counts,edge_counts[i,j])
         }
       }
     }
     bian_used <- cbind(bian,counts)
     colnames(bian_used) <- c('bian','counts') 
     bian_used <- as.data.frame(bian_used)
     bian_used <- bian_used[order(bian_used$bian),]
     return(bian_used)
   }
  # 输出每条边被各条最短路径的经过次数
  edge_counts <- edge_used(m_distance,m_path,edge_matrix)
  edge_counts <- edge_counts[order(edge_counts$counts),]
  edge_counts$group <- 'grey'
  edge_counts[c(1:6),'group'] <- 'lightgreen'
  edge_counts[c((bian_number-5):bian_number),'group'] <- "#FF9200FF"
  
  library(openxlsx)
  write.xlsx(edge_counts, file = "D:/documents/code_note/yunchou/tu/edge_counts.xlsx")
  library(ggplot2)
  edge_counts <- edge_counts[order(edge_counts$counts,decreasing = FALSE),]
  edge_counts$bian <- as.character(edge_counts$bian)
  p <- ggplot(edge_counts,aes(x = reorder(bian, counts,decreasing = TRUE),y=counts)) +  ggtitle("各边在最短路径的经过次数") + geom_col(fill=edge_counts$group)   + theme(plot.title = element_text(hjust = 0.5, vjust = 0.5,size = 16,face = 'bold'),axis.text.x = element_text(size = 1, hjust = 0.5)) + geom_text(aes(label = counts,hjust = 1.5, vjust = 0.5), position = position_nudge(y = 0.5),size=2.5)+  coord_flip() + labs(x='结点',y='次数')
                        
  print(p)
    
  
  
  
# 最小生成树 ####
  # 判断对称矩阵
  if(isSymmetric(lj_matrix)){
    print('lj_matrix 为对称矩阵')
  }
  library(igraph)
  library(ggplot2)
  # 生成节点标签
  generate_labels <- function(num_nodes) {
    labels <- paste0(1:num_nodes)
    return(labels)
  }
  point_labels <- generate_labels(point_number)
  # 输出最小生成树图
  generate_mst <- function(adj_matrix,labels) {
    adj_matrix[adj_matrix==0] <- Inf
    diag(adj_matrix) <- 0
    # 将邻接矩阵转换为igraph对象
    graph <- graph_from_adjacency_matrix(adj_matrix, mode = "undirected")
    
    # 计算最小生成树
      mst <- minimum.spanning.tree(graph)
    V(mst)$label <- labels
    
    # 设置绘图参数
    plot(mst, layout = layout.fruchterman.reingold, vertex.color = "white", vertex.size = 10, edge.width = 3)
    title(main='最小生成树')
    return(mst)
    }  
   mst <- generate_mst(lj_matrix,point_labels)  
  
  # 各顶点间最短距离
  mintree_matrix <- as_adjacency_matrix(mst)  
  mintree_matrix <- as.matrix(mintree_matrix) # 将最小生成树转换为矩阵
  for (i in 1:point_number) {
    for (j in 1:point_number) {
      if(mintree_matrix[i,j] == 1){
        mintree_matrix[i,j] <- lj_matrix[i,j]
      }
    }
  }               # 将最小生成树矩阵附加权重
  tree_result <- floyd(mintree_matrix)
  tree_distance <- as.data.frame(tree_result$D)
  mt_distance <- tree_result$D
  tree_path <- as.data.frame(tree_result$path)
  
  # 可视化
  library(reshape2)
  library(ggplot2)
  reli(mt_distance,'最小生成树上各顶点间最短距离')
  
  
  # 可视化两个最短距离矩阵差值
  chazhi <- mt_distance - m_distance
  reli(chazhi,'各顶点间最短距离差值（最小生成树与全图）')
# 最优5条边 ####
    # 添加最优 5 条边以降低最小生成树中各顶点间的最短距离  
  k <- 0
  mt_matrix <- mintree_matrix
  lj <- lj_matrix
  singele1 <- c(19,20,20,21,22)
  singele2 <- c(20,22,21,22,23)
  
  for (i in 1:length(singele1)) {
    print(lj[singele1[i],singele2[i]])
    mt_matrix[singele1[i],singele2[i]] <-  lj[singele1[i],singele2[i]]
    mt_matrix[singele2[i],singele1[i]] <-   lj[singele2[i],singele1[i]]
    }
  
  tree_result2 <- floyd(mt_matrix)
  tree_distance2 <- tree_result2$D
  reli(tree_distance2,'添加5条边后各顶点最短距离')
  reli(mt_distance,'添加5条边前各顶点最短距离')
  # 添加前后差值
  chazhi3 <- mt_distance - tree_distance2
  reli(chazhi3,'添加5条边后最短距离差值（最小生成树）')
 
  chazhi5 <- mt_distance - m_distance
  reli(chazhi5,'添加5条边前最短距离与全图最短距离差值')
  
  chazhi4 <- tree_distance2 - m_distance
  reli(chazhi4,'添加5条边后最短距离与全图最短距离差值')
  
  
  
  
  
  
  