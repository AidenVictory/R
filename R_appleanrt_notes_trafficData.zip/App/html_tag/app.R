library(shiny)

# Define UI ----
ui <- fluidPage(                    # create a display that automatically adjusts to the dimensions of your user’s browser window
                                    # placing elements in the fluidPage function

  titlePanel("My shinny app"),        # ***titlepanel***     ***sidebarLayout*** -- basic layout   
  
  sidebarLayout(                  
    position="left",               # position = "right"--move the siderbar to the right, and by default on the left
    sidebarPanel(h1("Installation"),p("Shiny is available on CRAN,so you can install it in the ususal way from your R console:"),
                 code("installed.packages(“shiny”)"),
                 br(),
                 br(),
                 br(),
                 br(),
                 br(),
                 img(src="rstudio.png",height=35,width=100),
                 p("Shiny is a product of ",span("RStudio",style="color:blue"))
                 ), 
    
    mainPanel(
      h1("Introducing Shiny"),
      p("Shiny is a new package from RStudio that makes it incredibly easy to build interactive web application with R."),
      br(),
      p("For an introduction and live examples,visit the ",span("Shiny homepage",style = "color:blue")),
      h2("Features"),
      p("-Build useful web applications with only a few lines of code-no JavaScript required."),
      p("-Shiny application are automatically 'live'in the same way that ",strong("spreadsheets"),"are live.Outputs change instantly as users modify inputs,without requiring a reload of the browser.")
    )
  )                                 
)    
# Define server logic ----
server <- function(input, output) {
  
}

# Run the app ----
shinyApp(ui = ui, server = server)