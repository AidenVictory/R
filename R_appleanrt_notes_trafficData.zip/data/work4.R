
data <- read.csv("D:/documents/stu/traffic/data/work4/data.csv")
####合并筛选####
library(tidyverse)
library(dplyr)
library(readxl)
data1.1<- read_excel("D:/documents/stu/traffic/data/coil_data/tmp001.xls",sheet="SQL Results")
data1.2 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp001.xls",sheet="SQL Results (2)")
data1.3 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp001.xls",sheet="SQL Results (3)")

data2 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp002.xls")

data3.1<- read_excel("D:/documents/stu/traffic/data/coil_data/tmp003.xls",sheet="SQL Results")
data3.2 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp003.xls",sheet="SQL Results (2)")
data3.3 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp003.xls",sheet="SQL Results (3)")

data4 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp004.xls")

data5 <- read_excel("D:/documents/stu/traffic/data/coil_data/tmp005.xls")

library(dplyr)

data01<- bind_rows(data1.1,data1.2,data1.3,data2,data3.1,data3.2,data3.3,data4,data5)
# 选取检测器
data_391 <- dplyr::filter(data01,FSTR_LOOPGROUPID == 'NHNX39(1)')
data_391 <- unique(data_391)


#### 故障数据识别 ####
  #### 独立判断法 ####
     # 速度分布条形图 
          library(ggplot2)
          ggplot(data_391,mapping=aes(x=FINT_SPEED))+
            geom_bar() +
            labs(title="未经故障数据检测的速度分布")
          sum(data_391$FINT_SPEED>=100,na.rm=TRUE)/nrow(data_391) # 速度大于100的数量
          # 选取100km/h作为速度阈值

     # 流量分布条形图 
          ggplot(data_391,aes(x=FINT_VOLUME))+
            geom_bar()+
            labs(title='未经故障数据检测的流量分布')
          # 选取13作为阈值
          sum(data_391$FINT_VOLUME>=12)/nrow(data_391) 
          # 阈值比例
     # 占有率分布条形图 
          ggplot(data_391,aes(x=FINT_OCCUPY))+
            geom_bar()+
            labs(title='未经故障数据检测的占有率分布')
          # 选取99%的占有率作为阈值
          sum(data_391$FINT_OCCUPY>=75) / nrow(data_391)
          # 阈值比例
          
     # 独立判断后数据 
      library(magrittr)
      data_391_duli <- data_391 %>% dplyr::filter(FINT_VOLUME<100) %>% dplyr::filter(
        FINT_VOLUME<13) %>% dplyr::filter(FINT_OCCUPY<99)

    
  #### 联合判断法 ####
      data_391_duli$lh <- 1      
      for (i in 1:nrow(data_391_duli)) {
        if(data_391_duli[i,'FINT_VOLUME' ]== 0){
          if(data_391_duli[i,'FINT_SPEED']!=0 ){
            data_391_duli[i,'lh'] <- 0
          }
          else if(data_391_duli[i,'FINT_OCCUPY']>0 & data_391_duli[i,'FINT_OCCUPY']<90){
            data_391_duli[i,'lh'] <- 0
          }
        }
        if(data_391_duli[i,'FINT_VOLUME']!=0){
          if(data_391_duli[i,'FINT_SPEED']==0){
            data_391_duli[i,'lh'] <- 0
          }
          else if(data_391_duli[i,'FINT_OCCUPY']==0){
            data_391_duli[i,'lh']<-0
          }
        }
      }
            
      data_391_lianhe <- dplyr::filter(data_391_duli,lh != 0)
      data_391_lh_error <- dplyr::filter(data_391_duli,lh == 0)
      data_391_lh_error<- data_391_lh_error[,-7]
      



  
  #### 平均有效车长法 ####
      data_391_length <- data_391_lianhe
      data_391_length$length <- 0 
      data_391_length$panduan <- 0
for (i in 1:nrow(data_391_length)) {
  if(data_391_length[i,'FINT_VOLUME']!=0){
    a <- data_391_length[i,'FINT_SPEED']
    b <- data_391_length[i,'FINT_OCCUPY']
    c <- data_391_length[i,'FINT_VOLUME']
    length <- a*b/(c*18)
    data_391_length[i,'length'] <- length
    if(length >= 3 & length <= 12){
      data_391_length[i,'panduan'] <- 1
    }
  }
  if(data_391_length[i,'FINT_VOLUME'] == 0){
    data_391_length[i,'panduan'] <- 1
  }
}      
  data_391_length <- dplyr::filter(data_391_length,panduan ==1)  
  
  #### 有效性的时序图 ####
      # 有效性小时时序图
  d <- data_391_length
  d <- d[,-c(7,8,9)]
  library(magrittr)
  library(dplyr)
  library(lubridate)
  d1 <- d %>% 
    mutate(FDT_TIME = as.POSIXct(FDT_TIME)) %>%
    group_by(group = ceiling_date(FDT_TIME,'1 hour')) %>%
    summarise(Count = n())
  d1 <- d1[-1,] 
  d1[1,'Count'] <-  d1[1,'Count'] + 1
  d1$valid <- d1$Count/180 
  frep_h <- ts(d1$valid,start = 1,frequency = 1)
  plot(frep_h,main='20s数据小时有效性-时序图',xlab='时间/小时',ylab='有效性')
  
  d2 <- d %>% 
    mutate(FDT_TIME = as.POSIXct(FDT_TIME)) %>%
    group_by(group = ceiling_date(FDT_TIME,'1 day')) %>%
    summarise(Count = n())
  d2 <- d2[-1,] 
  d2[1,'Count'] <-  d2[1,'Count'] +1
  d2$valid <- d2$Count/4320
  frep_d <- ts(d2$valid,start = 1,frequency = 1)
  plot(frep_d,main='20s数据日有效性-时序图',xlab='时间/天',ylab='有效性')
  
  
  
  
  
  
  
  #### 不同方法判别无效的数据记录数 ####
   duli <- nrow(data_391)-nrow(data_391_duli)
   lianhe <- nrow(data_391_duli)-nrow(data_391_lianhe)
   length <- nrow(data_391_lianhe)-nrow(data_391_length)
   wuxiao <- data.frame(ff = c('独立判断法','联合判断法','平均有效车长法'),count = c(duli,lianhe,length))
   library(ggplot2)   
   ggplot(wuxiao,aes(x=ff,y=count))+
     geom_col()+
     labs(title='不同方法判别无效的数据记录数',ylab='数量')+
     geom_text(aes(label = count), 
               position = position_stack(), # 可以不设置该参数
               vjust =0, hjust=0.5)
      
#### 故障数据修复 ####
    #### 随机选取100行--NA ####

    imputation1 <- read.csv("D:/documents/stu/traffic/data/work4/data.csv")
    im1 <- imputation1
    index_test_im <- sample(1:nrow(im1),100)
    test_im <- im1[index_test_im,]
    test_lab_im_1 <-  im1[index_test_im,1]
    train_im <- im1[-index_test_im,]
    train_lab_im <- im1[-index_test_im,1]
      
    #### knn ####
    library(FNN)
    
    knn03_im <- knn.reg(train = train_im, test= test_im, y = train_lab_im,k=3)
    knn_rmse_3_im <- data.frame(pred = knn03_im$pred, actual = test_lab_im_1) 
    k3_rmse_im <- sqrt(sum(((knn_rmse_3_im$pred)-(knn_rmse_3_im$actual))^2)/100)
    k3_mae_im <- sum(abs((knn_rmse_3_im$pred - knn_rmse_3_im$actual)/knn_rmse_3_im$actual))/100
    
    knn05_im <- knn.reg(train = train_im, test= test_im, y = train_lab_im,k=5)
    knn_rmse_5_im <- data.frame(pred = knn05_im$pred, actual = test_lab_im_1) 
    k5_rmse_im <- sqrt(sum(((knn_rmse_5_im$pred)-(knn_rmse_5_im$actual))^2)/100)
    k5_mae_im <- sum(abs((knn_rmse_5_im$pred - knn_rmse_5_im$actual)/knn_rmse_5_im$actual))/100
    
    metrics_knn_im <- data.frame(k=c(3,5),rmse=c(k3_rmse_im,k5_rmse_im),mae=c(k3_mae_im,k5_mae_im))
    
    #### 相邻时间平均值 ####
    da_na_im <- im1
    da_na_im[index_test_im,1] <- NA
    for (i in 1:nrow(da_na_im)) {
      if(is.na(da_na_im[i,1])){
        if(i<=3 & i>=2){
          da_na_im[i,1] <- da_na_im[i-1,1]
        }
        else{
          da_na_im[i,1] <- (da_na_im[i-1,1] + da_na_im[i-2,1] + da_na_im[i-3,1])/3
        }
      }
    }
    xl3_im <- data.frame(actual=test_lab_im_1,xl3=da_na_im[index_test_im,1]) 
    xl3_rmse_im <- sqrt(sum(((xl3_im$xl3)-(xl3_im$actual))^2)/100)
    xl3_mae_im <- sum(abs((xl3_im$xl3 - xl3_im$actual)/xl3_im$actual))/100
    
    da_na_im <- im1
    da_na_im[index_test_im,1] <- NA
    for (i in 1:nrow(da_na_im)) {
      if(is.na(da_na_im[i,1])){
        if(i<=5 & i>=2){
          da_na_im[i,1] <- da_na_im[i-1,1]
        }
        else{
          da_na_im[i,1] <- (da_na_im[i-1,1] + da_na_im[i-2,1] + da_na_im[i-3,1] + da_na_im[i-4,1] + da_na_im[i-5,1])/5
        }
      }
    }
    xl5_im <- data.frame(actual=test_lab_im_1,xl5=da_na_im[index_test_im,1]) 
    xl5_rmse_im <- sqrt(sum((xl5_im$xl5)-(xl5_im$actual))^2/100)
    xl5_mae_im <- sum(abs((xl5_im$xl5 - xl5_im$actual)/xl5_im$actual))/100
    
    metrics_xl_im <- data.frame(xl=c(3,5),rmse=c(xl3_rmse_im,xl5_rmse_im),mae=c(xl3_mae_im,xl5_mae_im))
    
    
    
#### 数据平滑处理 ####
    #### 选取数据 ####
    library(magrittr)
    d1 <- as.data.frame(d0) %>% dplyr::filter(FDT_TIME >='2010-04-18 24:00:00' & FDT_TIME <= '2010-04-19 02:00:00')
    d2 <- d1[,'FINT_SPEED']
    #### 移动平均 ####
    library(forecast)        
    plot(ma(d2,3),main="移动平均(k=3)",xlab='time',ylab='速度')    
    plot(ma(d2,5),main="移动平均(k=5)",xlab='time',ylab='速度')    
    plot(d2,main="原数据",type="l",xlab='time',ylab='速度')
    plot(d2,main='移动平均(k=3)',cex=0.5,col='black')
    lines(ma(d2,3))
    plot(d2,main='移动平均(k=5)',cex=0.5,col='black')
    lines(ma(d2,5))
    
    
    #### 指数平滑 ####
    plot(ses(d2,alpha=0.3),main="简单指数平滑(α=0.3)",xlab='time/20s',ylab='速度',col='black')
    points(d2,cex=0.5,col='black')
    plot(ses(d2,alpha=0.6),main="简单指数平滑(α=0.6)",xlab='time/20s',ylab='速度',col='black')
    points(d2,cex=0.5,col='black')
    
#### 数据可视化处理 ####
   
    d3 <- as.data.frame(d0)
    d4 <- d3[,'FINT_SPEED']
    library(ggplot2)
    ggplot(d0,aes(x = FINT_SPEED))+
      stat_ecdf(color = "black")+
      labs(xlab='值',ylab='累计分布',title='速度')+
      theme(plot.title = element_text(vjust = -0.1,hjust = 0.5)) 
      
    x <- rnorm(n=nrow(d3),mean=mean(d4),sd=sd(d4))
    
    d_rnorm <-  data.frame(x=x,y=(x-mean(d4))/sd(d4))
    ggplot(d_rnorm,aes(x = y))+
      stat_ecdf(color = "black")+
      scale_x_continuous(limits = c(-4, 5), breaks = seq(-4, 5, 1)) +
      labs(xlab='值',ylab='累计分布',title='速度')+
      theme(plot.title = element_text(vjust = -0.1,hjust = 0.5)) 
    
    
    qqnorm(d4,main="速度的正态QQ图",xlab='正态值',ylab='数据值',pch=20,cex=0.5)
    qqline(d4,col='blue')
    
    