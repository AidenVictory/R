##### 读取data数据 ####
  # 读取数据
      data <- read.csv("D:/documents/stu/traffic/data/work3/taxi1.csv")
  # 转换时间序列
      library(lubridate)
      data$stime <- strptime(data$stime,'%m/%d/%Y  %H:%M')
      data$etime <- strptime(data$etime,'%m/%d/%Y  %H:%M')
  # 筛选过滤掉出发时刻和到达时刻相同的错误数据
      data <- filter(data,stime != etime)
  
  data1 <- data[order(data$stime),]


##### 订单生成和完成量 ####
      data1 <- within(data1,{
        group_stime <- NA
        group_stime[stime >= '2018-04-18 0:00:00' & stime <= '2018-04-18 1:00:00'] = '1'
        group_stime[stime > '2018-04-18 1:00:00' & stime <= '2018-04-18 2:00:00'] = '2'
        group_stime[stime > '2018-04-18 2:00:00' & stime <= '2018-04-18 3:00:00'] = '3'  
        group_stime[stime > '2018-04-18 3:00:00' & stime <= '2018-04-18 4:00:00'] = '4'
        group_stime[stime > '2018-04-18 4:00:00' & stime <= '2018-04-18 5:00:00'] = '5'
        group_stime[stime > '2018-04-18 5:00:00' & stime <= '2018-04-18 6:00:00'] = '6'  
        group_stime[stime > '2018-04-18 6:00:00' & stime <= '2018-04-18 7:00:00'] = '7'
        group_stime[stime > '2018-04-18 7:00:00' & stime <= '2018-04-18 8:00:00'] = '8'
        group_stime[stime > '2018-04-18 8:00:00' & stime <= '2018-04-18 9:00:00'] = '9'
        group_stime[stime > '2018-04-18 9:00:00' & stime <= '2018-04-18 10:00:00'] = '10'  
        group_stime[stime > '2018-04-18 10:00:00' & stime <= '2018-04-18 11:00:00'] = '11'
        group_stime[stime > '2018-04-18 11:00:00' & stime <= '2018-04-18 12:00:00'] = '12'
        group_stime[stime > '2018-04-18 12:00:00' & stime <= '2018-04-18 13:00:00'] = '13'
        group_stime[stime > '2018-04-18 13:00:00' & stime <= '2018-04-18 14:00:00'] = '14'  
        group_stime[stime > '2018-04-18 14:00:00' & stime <= '2018-04-18 15:00:00'] = '15'
        group_stime[stime > '2018-04-18 15:00:00' & stime <= '2018-04-18 16:00:00'] = '16'
        group_stime[stime > '2018-04-18 16:00:00' & stime <= '2018-04-18 17:00:00'] = '17'
        group_stime[stime > '2018-04-18 17:00:00' & stime <= '2018-04-18 18:00:00'] = '18'
        group_stime[stime > '2018-04-18 18:00:00' & stime <= '2018-04-18 19:00:00'] = '19'
        group_stime[stime > '2018-04-18 19:00:00' & stime <= '2018-04-18 20:00:00'] = '20'
        group_stime[stime > '2018-04-18 20:00:00' & stime <= '2018-04-18 21:00:00'] = '21'
        group_stime[stime > '2018-04-18 21:00:00' & stime <= '2018-04-18 22:00:00'] = '22'
        group_stime[stime > '2018-04-18 22:00:00' & stime <= '2018-04-18 23:00:00'] = '23'
        group_stime[stime > '2018-04-18 23:00:00' ] = '24' 
      })
      produce_order <- as.data.frame(table(data1$group_stime))
      produce_order$type <- '生成量'
      colnames(produce_order) <- c('hour','order','type')
      data1 <- within(data1,{
        group_etime <- NA
        group_etime[etime > '2018-04-18 0:00:00' & etime <= '2018-04-18 1:00:00'] = '1'
        group_etime[etime > '2018-04-18 1:00:00' & etime <= '2018-04-18 2:00:00'] = '2'
        group_etime[etime > '2018-04-18 2:00:00' & etime <= '2018-04-18 3:00:00'] = '3'  
        group_etime[etime > '2018-04-18 3:00:00' & etime <= '2018-04-18 4:00:00'] = '4'
        group_etime[etime > '2018-04-18 4:00:00' & etime <= '2018-04-18 5:00:00'] = '5'
        group_etime[etime > '2018-04-18 5:00:00' & etime <= '2018-04-18 6:00:00'] = '6'  
        group_etime[etime > '2018-04-18 6:00:00' & etime <= '2018-04-18 7:00:00'] = '7'
        group_etime[etime > '2018-04-18 7:00:00' & etime <= '2018-04-18 8:00:00'] = '8'
        group_etime[etime > '2018-04-18 8:00:00' & etime <= '2018-04-18 9:00:00'] = '9'
        group_etime[etime > '2018-04-18 9:00:00' & etime <= '2018-04-18 10:00:00'] = '10'  
        group_etime[etime > '2018-04-18 10:00:00' & etime <= '2018-04-18 11:00:00'] = '11'
        group_etime[etime > '2018-04-18 11:00:00' & etime <= '2018-04-18 12:00:00'] = '12'
        group_etime[etime > '2018-04-18 12:00:00' & etime <= '2018-04-18 13:00:00'] = '13'
        group_etime[etime > '2018-04-18 13:00:00' & etime <= '2018-04-18 14:00:00'] = '14'  
        group_etime[etime > '2018-04-18 14:00:00' & etime <= '2018-04-18 15:00:00'] = '15'
        group_etime[etime > '2018-04-18 15:00:00' & etime <= '2018-04-18 16:00:00'] = '16'
        group_etime[etime > '2018-04-18 16:00:00' & etime <= '2018-04-18 17:00:00'] = '17'
        group_etime[etime > '2018-04-18 17:00:00' & etime <= '2018-04-18 18:00:00'] = '18'
        group_etime[etime > '2018-04-18 18:00:00' & etime <= '2018-04-18 19:00:00'] = '19'
        group_etime[etime > '2018-04-18 19:00:00' & etime <= '2018-04-18 20:00:00'] = '20'
        group_etime[etime > '2018-04-18 20:00:00' & etime <= '2018-04-18 21:00:00'] = '21'
        group_etime[etime > '2018-04-18 21:00:00' & etime <= '2018-04-18 22:00:00'] = '22'
        group_etime[etime > '2018-04-18 22:00:00' & etime <= '2018-04-18 23:00:00'] = '23'
        group_etime[etime > '2018-04-18 23:00:00' ] = '24' 
      })
      finish_order <- as.data.frame(table(data1$group_etime))
      finish_order$type <- '完成量'
      colnames(finish_order) <- c('hour','order','type')
      # 分组
      pro_fin_order <- rbind(produce_order,finish_order)
      pro_fin_order$hour <- as.numeric(as.character(produce_order$hour))
      pro_fin_order <- pro_fin_order[order(pro_fin_order$hour),]
      # 合并生成/完成数据
      library(tidyverse)
      p <- ggplot(data = pro_fin_order,
                  mapping = aes(
                    x = hour,
                    y = order,
                    group = type,
                    color = type)) 
      p + geom_line() + labs(
        x = "时间/小时",
        y = "订单量/单",
        title = "上海市订单生成量及完成量小时变化统计",
        subtitle = "2018年4月18日 星期三",
        caption = "数据来源: taxi.csv"  )  + guides(fill = guide_legend(label.position = "topleft", label.hjust = 1))+
        scale_x_continuous(breaks=seq(1 ,24, 2)) 
      # 画图
#### 订单时长分布 ####
      data2 <- data
      data2$diff_time <- difftime(data2$etime, data2$stime, units = "mins")
      data2$diff_time <- as.numeric(as.character(data2$diff_time))
      diff_time <- as.data.frame(table(data2$diff_time))
      colnames(diff_time) <- c('dif_time','frep')
      diff_time$dif_time <- as.numeric(as.character(diff_time$dif_time))
      p <- ggplot(data = diff_time,
                  mapping = aes(x = dif_time, y = frep))
      p + geom_col() + labs(
        x = "时长(min)",
        y = "频数",
        title = "订单时长分布",
        subtitle = "2018-04-18",
        caption = "数据来源: taxi.csv")

#### 出租车里程分布 ####
      distance <- as.data.frame(table(data2$dis))
      colnames(distance) <- c('dis','frep')
      p <- ggplot(data = distance,
                  mapping = aes(x = dis, y = frep))
      p + geom_col() + labs(
        x = "里程(km)",
        y = "频数",
        title = "订单里程分布",
        subtitle = "2018-04-18",
        caption = "数据来源: taxi.csv"  )+
        scale_x_continuous(breaks=seq( 0,50, 5))
        

#### 出租车完成订单数量 ####
      car_order <- as.data.frame(table(data$carID))
      colnames(car_order) <- c('car_order','frep')
      car_order$car_order <- as.numeric(as.character(car_order$car_order))
      car_order2 <- as.data.frame(table(car_order$frep))
      colnames(car_order2) <- c('car_orders','frep')
      x <- c
      p <- ggplot(data = car_order2,
                  mapping = aes(x = car_orders, y = frep))
      p + geom_col() + labs(
        x = "车辆完成订单量",
        y = "频数",
        title = "出租车完成订单量",
        subtitle = "2018-04-18",
        caption = "数据来源: taxi.csv"  ) 
      
      

      
      
#### 出租车出行空间分布特征 ####
      library(sf)
      shp1 <- sf::read_sf("D:/documents/stu/traffic/data/work3/shanghai_districts/shanghai_districts.shp")

      data_area <- read.csv("D:/documents/stu/traffic/data/work3/taxi2.csv")
      # 将原有的csv文件转化为UTF-8的csv文件
      library(lubridate)
      data_area$stime <- strptime(data_area$stime,'%m/%d/%Y  %H:%M')
      data_area$etime <- strptime(data_area$etime,'%m/%d/%Y  %H:%M')
      data_area <- dplyr::filter(data_area,stime != etime)
      
      area_eorder <- as.data.frame(table(data_area$e_district_name))
      area_eorder$Var1 <- as.character(area_eorder$Var1)
      colnames(area_eorder) <- c('name','到达订单数量')
      
      library(dplyr)
      area_eorder_geom <- left_join(shp1,area_eorder,by='name') 
      # 合并得到订单量和地域及几何位置
      qu <- read.csv("D:/documents/stu/traffic/data/work3/qu.csv")
      area_qu <- left_join(area_eorder_geom,qu,by = 'name')
      library(ggplot2)
      # 到达订单数量分布
      ggplot()+
        geom_sf(aes(fill=到达订单数量),area_qu)+
        ggtitle("上海各区到达订单数量分布","2018-04-18") +
        scale_fill_gradient(low="white",high="steelblue")+
        geom_text(aes(x = gcj_s_lng,y = gcj_s_lat,label=name),area_qu,size=2)+
        theme(plot.title = element_text(hjust = 0.5),
              plot.subtitle = element_text(hjust = 0.5),
              axis.text = element_blank(),
              axis.ticks = element_blank(),
              axis.title = element_blank(),
              panel.grid = element_blank(),
              panel.background = element_blank())
      
      # 出发订单数量分布
      area_sorder <- as.data.frame(table(data_area$s_district_name))
      area_sorder$Var1 <- as.character(area_sorder$Var1)
      colnames(area_sorder) <- c('name','出发订单数量')
      
      area_sorder_geom <- left_join(shp1,area_sorder,by='name') 
      area_qu_e <- left_join(area_sorder_geom,qu,by = 'name')
      
      ggplot()+
        geom_sf(aes(fill=出发订单数量),area_qu_e)+
        ggtitle("上海各区出发订单数量分布","2018-04-18") +
        scale_fill_gradient(low="white",high="steelblue")+
        geom_text(aes(x = gcj_s_lng,y = gcj_s_lat,label=name),area_qu_e,size=2)+
        theme(plot.title = element_text(hjust = 0.5),
              plot.subtitle = element_text(hjust = 0.5),
              axis.text = element_blank(),
              axis.ticks = element_blank(),
              axis.title = element_blank(),
              panel.grid = element_blank(),
              panel.background = element_blank())
      
      # 出发订单点位分布
      ggplot()+
                geom_point(aes(x=gcj_s_lng,y=gcj_s_lat,fill=s_district_name,color=s_district_name),data_area,size=1)
      
      
#### 静安区出行时空分布  ####
      jingan_data <- filter(data_area, s_district_name == '静安区')
     
      jingan_data <- within(jingan_data,{
        group_stime <- NA
        group_stime[stime > '2018-04-18 0:00:00' & stime <= '2018-04-18 1:00:00'] = '1'
        group_stime[stime > '2018-04-18 1:00:00' & stime <= '2018-04-18 2:00:00'] = '2'
        group_stime[stime > '2018-04-18 2:00:00' & stime <= '2018-04-18 3:00:00'] = '3'  
        group_stime[stime > '2018-04-18 3:00:00' & stime <= '2018-04-18 4:00:00'] = '4'
        group_stime[stime > '2018-04-18 4:00:00' & stime <= '2018-04-18 5:00:00'] = '5'
        group_stime[stime > '2018-04-18 5:00:00' & stime <= '2018-04-18 6:00:00'] = '6'  
        group_stime[stime > '2018-04-18 6:00:00' & stime <= '2018-04-18 7:00:00'] = '7'
        group_stime[stime > '2018-04-18 7:00:00' & stime <= '2018-04-18 8:00:00'] = '8'
        group_stime[stime > '2018-04-18 8:00:00' & stime <= '2018-04-18 9:00:00'] = '9'
        group_stime[stime > '2018-04-18 9:00:00' & stime <= '2018-04-18 10:00:00'] = '10'  
        group_stime[stime > '2018-04-18 10:00:00' & stime <= '2018-04-18 11:00:00'] = '11'
        group_stime[stime > '2018-04-18 11:00:00' & stime <= '2018-04-18 12:00:00'] = '12'
        group_stime[stime > '2018-04-18 12:00:00' & stime <= '2018-04-18 13:00:00'] = '13'
        group_stime[stime > '2018-04-18 13:00:00' & stime <= '2018-04-18 14:00:00'] = '14'  
        group_stime[stime > '2018-04-18 14:00:00' & stime <= '2018-04-18 15:00:00'] = '15'
        group_stime[stime > '2018-04-18 15:00:00' & stime <= '2018-04-18 16:00:00'] = '16'
        group_stime[stime > '2018-04-18 16:00:00' & stime <= '2018-04-18 17:00:00'] = '17'
        group_stime[stime > '2018-04-18 17:00:00' & stime <= '2018-04-18 18:00:00'] = '18'
        group_stime[stime > '2018-04-18 18:00:00' & stime <= '2018-04-18 19:00:00'] = '19'
        group_stime[stime > '2018-04-18 19:00:00' & stime <= '2018-04-18 20:00:00'] = '20'
        group_stime[stime > '2018-04-18 20:00:00' & stime <= '2018-04-18 21:00:00'] = '21'
        group_stime[stime > '2018-04-18 21:00:00' & stime <= '2018-04-18 22:00:00'] = '22'
        group_stime[stime > '2018-04-18 22:00:00' & stime <= '2018-04-18 23:00:00'] = '23'
        group_stime[stime > '2018-04-18 23:00:00' ] = '24' 
      })
      ja_produce_order <- as.data.frame(table(jingan_data$group_stime))
      colnames(ja_produce_order) <- c('time','frep')
      ja_produce_order$type <- '离开'
  
      
      jingan_data_e <- filter(data_area,e_district_name == '静安区')
      jingan_data_e <- within(jingan_data_e,{
        group_etime <- NA
        group_etime[etime > '2018-04-18 0:00:00' & etime <= '2018-04-18 1:00:00'] = '1'
        group_etime[etime > '2018-04-18 1:00:00' & etime <= '2018-04-18 2:00:00'] = '2'
        group_etime[etime > '2018-04-18 2:00:00' & etime <= '2018-04-18 3:00:00'] = '3'  
        group_etime[etime > '2018-04-18 3:00:00' & etime <= '2018-04-18 4:00:00'] = '4'
        group_etime[etime > '2018-04-18 4:00:00' & etime <= '2018-04-18 5:00:00'] = '5'
        group_etime[etime > '2018-04-18 5:00:00' & etime <= '2018-04-18 6:00:00'] = '6'  
        group_etime[etime > '2018-04-18 6:00:00' & etime <= '2018-04-18 7:00:00'] = '7'
        group_etime[etime > '2018-04-18 7:00:00' & etime <= '2018-04-18 8:00:00'] = '8'
        group_etime[etime > '2018-04-18 8:00:00' & etime <= '2018-04-18 9:00:00'] = '9'
        group_etime[etime > '2018-04-18 9:00:00' & etime <= '2018-04-18 10:00:00'] = '10'  
        group_etime[etime > '2018-04-18 10:00:00' & etime <= '2018-04-18 11:00:00'] = '11'
        group_etime[etime > '2018-04-18 11:00:00' & etime <= '2018-04-18 12:00:00'] = '12'
        group_etime[etime > '2018-04-18 12:00:00' & etime <= '2018-04-18 13:00:00'] = '13'
        group_etime[etime > '2018-04-18 13:00:00' & etime <= '2018-04-18 14:00:00'] = '14'  
        group_etime[etime > '2018-04-18 14:00:00' & etime <= '2018-04-18 15:00:00'] = '15'
        group_etime[etime > '2018-04-18 15:00:00' & etime <= '2018-04-18 16:00:00'] = '16'
        group_etime[etime > '2018-04-18 16:00:00' & etime <= '2018-04-18 17:00:00'] = '17'
        group_etime[etime > '2018-04-18 17:00:00' & etime <= '2018-04-18 18:00:00'] = '18'
        group_etime[etime > '2018-04-18 18:00:00' & etime <= '2018-04-18 19:00:00'] = '19'
        group_etime[etime > '2018-04-18 19:00:00' & etime <= '2018-04-18 20:00:00'] = '20'
        group_etime[etime > '2018-04-18 20:00:00' & etime <= '2018-04-18 21:00:00'] = '21'
        group_etime[etime > '2018-04-18 21:00:00' & etime <= '2018-04-18 22:00:00'] = '22'
        group_etime[etime > '2018-04-18 22:00:00' & etime <= '2018-04-18 23:00:00'] = '23'
        group_etime[etime > '2018-04-18 23:00:00' ] = '24' 
      })
      ja_finish_order <- as.data.frame(table(jingan_data_e$group_etime))
      colnames(ja_finish_order) <- c('time','frep')
      ja_finish_order$type <- '到达'
      
      ja_pro_fin_oredr <- rbind(ja_produce_order,ja_finish_order)
      ja_pro_fin_oredr$time <- as.numeric(as.character(ja_pro_fin_oredr$time))
      ja_pro_fin_oredr <- ja_pro_fin_oredr[order(ja_pro_fin_oredr$time),]
      #  绘图
      p <- ggplot(data = ja_pro_fin_oredr,
                  mapping = aes(
                    x = time,
                    y = frep,
                    group = type,
                    color = type)) 
      
      p + geom_line() + labs(
        x = "时间/小时",
        y = "订单量/单",
        title = "上海市静安区出行时空分布",
        subtitle = "2018年4月18日",
        caption = "数据来源: taxi.csv"  )  + guides(fill = guide_legend(label.position = "topleft", label.hjust = 1))+
        scale_x_continuous(breaks=seq(1 ,24, 2)) 
      
      
      
      
      
      
      
     
      
      
      
  
      
      
      
      
      
      
      
      
#### 订单密度 ####
      summary(data_area$gcj_s_lng)
      summary(data_area$gcj_s_lat)
      bbox <- c(bottom = 31.1, top = 31.45 , right = 121.8, left = 121.3)
      usmap <- get_stamenmap(bbox = bbox, zoom = 15, maptype = 'toner') 
      
      # 5:00 - 11:00 
      hour_5_11_s <- data_area %>% dplyr::filter(stime > '2018-04-18 05:00:00' )
      hour_5_11_s <- hour_5_11_s %>% dplyr::filter(stime < '2018-04-18 11:00:00' )
      
      ggmap(usmap) + 
        geom_point(data = hour_5_11_s, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='lightgreen') +
        geom_density_2d(data = hour_5_11_s, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle(' 5:00 - 11:00 订单起点密度分布')
      
      hour_5_11_e <- data_area %>% dplyr::filter(etime > '2018-04-18 05:00:00' )
      hour_5_11_e <- hour_5_11_e %>% dplyr::filter(etime < '2018-04-18 11:00:00' )
      
      ggmap(usmap) + 
        geom_point(data = hour_5_11_e, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='palegoldenrod') +
        geom_density_2d(data = hour_5_11_e, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle(' 5:00 - 11:00 订单终点密度分布')
      # 11:00- 22:00
      hour_11_22_s <- data_area %>% dplyr::filter(stime > '2018-04-18 11:00:00' )
      hour_11_22_s <- hour_11_22_s %>% dplyr::filter(stime < '2018-04-18 22:00:00' )
      ggmap(usmap) + 
        geom_point(data = hour_11_22_s, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='lightgreen') +
        geom_density_2d(data = hour_11_22_s, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle(' 11:00 - 22:00 订单起点密度分布')
    
      
      
      hour_11_22_e <- data_area %>% dplyr::filter(etime > '2018-04-18 11:00:00' )
      hour_11_22_e <- hour_11_22_e %>% dplyr::filter(etime < '2018-04-18 22:00:00' )
      ggmap(usmap) + 
        geom_point(data = hour_11_22_e, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='palegoldenrod') +
        geom_density_2d(data = hour_11_22_e, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle(' 11:00 - 22:00 订单终点密度分布')
      # 22:00 - 24:00
      hour_22_24_s <- data_area %>% dplyr::filter(stime > '2018-04-18 22:00:00' )
      ggmap(usmap) + 
        geom_point(data = hour_22_24_s, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='lightgreen') +
        geom_density_2d(data = hour_22_24_s, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle(' 22:00 - 24:00 订单起点密度分布')
     
      hour_22_e <- data_area %>% dplyr::filter(etime > '2018-04-18 22:00:00' )
      ggmap(usmap) + 
        geom_point(data = hour_22_e, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='palegoldenrod') +
        geom_density_2d(data = hour_22_e, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle(' 22:00 - 24:00 订单终点密度分布')

      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      # 点的分布 
      ggmap(usmap) + 
             geom_point(data = data_area, 
                                         mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='lightgrey') +
        geom_density_2d(data = data_area, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
             ggtitle(' 5:00 - 11:00 订单起点密度分布')
      
      
      # 小范围
      bbox <- c(bottom = 31.1, top = 31.45 , right = 121.8, left = 121.3)
      usmap <- get_stamenmap(bbox = bbox, zoom = 15, maptype = 'toner') 
      ggmap(usmap) + 
        geom_point(data = data_area, 
                   mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=0.4,color='lightsteelblue') +
        geom_density_2d(data = data_area, 
                        mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
        ggtitle('Spread of counties across SH')
      
      
      # 筛选早八数据
        hour_7_9_s <- data_area %>% dplyr::filter(stime > '2018-04-18 07:00:00' )
        hour_7_9_s <- hour_7_9_s %>% dplyr::filter(stime < '2018-04-18 09:00:00' )
        hour_7_9_e <- data_area %>% dplyr::filter(etime > '2018-04-18 07:00:00' )
        hour_7_9_e <- hour_7_9_s %>% dplyr::filter(etime < '2018-04-18 09:00:00' )
        bbox <- c(bottom = 31.1, top = 31.45 , right = 121.8, left = 121.3)
        usmap <- get_stamenmap(bbox = bbox, zoom = 15, maptype = 'toner') 
        ggmap(usmap) + 
          geom_point(data = hour_7_9_s, 
                     mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=0.8,stroke=0,alpha=1,color='grey') +
          geom_density_2d(data = data_area, 
                          mapping = aes(x = gcj_s_lng, y = gcj_s_lat),color='blue',show.legend = TRUE) +
          ggtitle('5:00-9:00 OD分布')
          
        
        
        ggmap(usmap) +
          geom_point(data = hour_7_9_e, mapping = aes(x = gcj_s_lng, y = gcj_s_lat),size=,stroke=0,alpha=0.4,color='thistle1') +
          geom_density_2d(data = data_area, 
                          mapping = aes(x = gcj_s_lng, y = gcj_s_lat),color='purple4')
        
        hour_7_9_e$type = 'lightblue'
        hour_7_9_s$type = 'lightgreen'
        hour_7_9 <- bind_rows(hour_7_9_s,hour_7_9_e)
        ggmap(usmap) +
          geom_point(data = hour_7_9, 
                     mapping = aes(x = gcj_s_lng, y = gcj_s_lat,color = type,group = type),size=0.8,stroke=0,alpha=1) +
          stat_density_2d(data = hour_7_9,geom = "polygon", aes(alpha = ..level.., fill = type))
      
        
        ggmap(usmap) +
          + stat_density_2d(data = hour_7_9,geom = "polygon", aes(x=hour_7_9$gcj_s_lng,y=hour_7_9$gcj_s_lat,group=type, fill = type))
        
        ggplot(hour_7_9,aes(x=hour_7_9$gcj_s_lng,y=hour_7_9$gcj_s_lat,group=type))+
          + stat_density_2d(geom = "polygon", aes(alpha = ..level.., fill = type))
      
       # 二维密度
       ggmap(usmap) + 
              geom_density_2d(data = data_area, 
                                               mapping = aes(x = gcj_s_lng, y = gcj_s_lat)) +
              ggtitle('Spread of counties across US')
       # 出发订单点位分布
       ggplot()+
         geom_point(aes(x=gcj_s_lng,y=gcj_s_lat,fill=s_district_name,color=s_district_name),data_area,size=1)
       # 无底图点分布
       ggplot()+
          geom_density2d(data_area,mapping = aes(x = gcj_s_lng, y = gcj_s_lat))
       #无底图密度线分布
       
       
       
       
       
       
       
       
       
       