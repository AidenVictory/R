#### 数据预处理 ####
  data0 <- read.csv("D:/documents/stu/traffic/data/work5/obike.csv")
  setDT(data0)
  # distance
  library('geosphere')
  data0[, distance := distHaversine(matrix(c(olgt, olat), ncol = 2),
                                                                         matrix(c(dlgt, dlat), ncol = 2))]
  # speed
  data0$time_s <- as.numeric(difftime(as.POSIXct(as.character(data0$time),format="%H:%M"),
                                      as.POSIXct(as.character('00:00'),format="%H:%M"),units = 'secs'))
  data0$speed <- data0$distance/data0$time_s*3.6
  library(magrittr)  
  data1 <- data0 %>% dplyr::filter(speed<25)  
  
   
    
#### 特征提取 ####
  summary(data1$olgt)
  summary(data1$olat)
  library("ggplot2")
  theme_set(theme_bw())
  library("sf")  
  library("rnaturalearth")
  library("rnaturalearthdata")
  world <- ne_countries(scale = "medium", returnclass = "sf")
  # O点地理位置
  ggplot(data = world) +
    geom_sf() +
    coord_sf(xlim = c(121.29, 121.61), ylim = c(24.91, 25.15), expand = FALSE) +
    geom_point(data1, 
               mapping = aes(x = olgt, y = olat),size=0.9,stroke=0,alpha=0.4) +
               ggtitle("O点地理位置")
  


  
  
  
  
  
  
  
#### 相似性度量 ####
  install.packages('philentropy')
  library('philentropy')
  library(tidyr)
  data2 <- data1 %>% dplyr::select(olgt,olat)
  ou_distance <- distance(data2, method = "euclidean", p = NULL, test.na = TRUE,
           unit = "log", est.prob = NULL)
  ou_distance <- as.data.frame(ou_distance)  
#### k_means聚类 ####
  # k-means函数编写
  kms <- function(X, K, try_max = 300,trace=TRUE) {
    
    # 行数，列数
    n <- nrow(X)
    p <- ncol(X)
    
    # 初始化k个聚类中心（从数据集中随机选取K个点）
    sample_start <- sample.int(n, K)
    centers <- X[sample_start, ]
    
    # 初始化每个点默认属于的聚类中心
    newcluster <- rep(NA, n)
    
    # 执行迭代
    tryit <- 1
    while (tryit <= try_max ) {
      
      # 分配每个数据点到离它最近的聚类中心，更新newcluster
      for (i in 1:n) {
        d <- apply(centers, 1, function(x) sum((X[i,] - x)^2))
        newcluster[i] <- which(d == min(d))
        
      }
      
      
      # 存储旧的聚类中心
      old_centers <- centers
      # 更新聚类中心
      for (i in 1:K) {
        Xk <- X[newcluster == i,]
        centers[i,] <- apply(Xk, 2, mean) }
      # 聚类中心检查
      if(all(as.data.frame(centers) == as.data.frame(old_centers))){
        break
      }
      tryit <- tryit + 1
      
    }
    
    # 返回分类结果
    list(cluster = newcluster, centers = centers)
  }
  result <- kms(data2,8)
  
  plot(data2, col = result$cluster, main="Kmeans(k=8)")
  points(result$centers,pch = 10, cex = 2)
  
  result2 <- kms(data2,4)
  plot(data2, col = result2$cluster, main="Kmeans(k=4)")
  points(result2$centers,pch = 10, cex = 2)
  
  # 轮廓系数
  luokuo_data <- silhouette (result$cluster, ou_distance)
  luokuo <- mean(luokuo_data[,3])
  
  luokuo_data2 <- silhouette (result2$cluster, ou_distance)
  luokuo2 <- mean(luokuo_data2[,3])
  
  # CH指数的函数
  calCH <- function(X,labels){ 
    ##X必须行为样本，列为特征
    labels_n <- length(unique(labels))
    samples_n <- nrow(X)
    X_mean <- apply(X,2,mean)
    ex_disp <- c()
    in_disp <- c()
    for (i in c(1:labels_n)) {
      cluster_k <- X[which(labels==i),]
      mean_k <- apply(cluster_k,2,mean)
      a1 <- nrow(cluster_k)*sum((mean_k-X_mean)^2)
      ex_disp <- c(ex_disp,a1)
      a2 <- sum((t(t(cluster_k)-mean_k))^2)
      in_disp <- c(in_disp,a2)
    }
    k1<- sum(ex_disp)
    k2<- sum(in_disp)
    if(k2==0)
    {
      return(1)
    }
    else
    {
      return((k1*(samples_n-labels_n))/(k2*(labels_n-1)))
    }
  }
  k8 <- calCH(data2,result$cluster)
  k4 <- calCH(data2,result2$cluster)
  
  
  
   