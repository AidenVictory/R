#  将整数转换成2~16为进制基数的字符串

def toStr(n,base):
    convertString = "0123456789ABCDEF"
    if n < base:                                                # 基本情况：n小于进制基数
        return convertString[n]                                 # 
    else:
        return toStr(n//base,base) + convertString[n%base]      # 整除的递归，完美执行循环中的下一步 -- 取余在后，左到右的字符串拼接

def main():
    print(toStr(10,10))
    
    print(toStr(10,2))
    
main()