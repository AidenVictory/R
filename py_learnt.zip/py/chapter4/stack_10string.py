# 进行递归调用之前把字符串压入栈中
from pythonds import Stack
rStack = Stack()

def toStr(n,base):
    convertString = "0123456789ABCDEF"
    if n < base:
        rStack.push(convertString[n])
    else :
        rStack.push(convertString[n % base])
        toStr(n // base,base)     
    return rStack

def main():
    r = toStr(10,2)
    a = ''
    while not r.isEmpty():
        a = a + r.pop()
    print(a)
main()