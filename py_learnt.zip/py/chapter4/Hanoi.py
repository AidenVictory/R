# 汉诺塔问题的递归
def moveTower(height,fromPole,toPole,withPole):
    if height >= 1:
        moveTower(height-1,fromPole,withPole,toPole) # 递归调用--将除了最后一个盘子以外的其他所有盘子从起点柱子移到中间柱子
        moveDisk(fromPole,toPole)                           # 将最后一个盘子移到终点柱子
        moveTower(height-1,withPole,toPole,fromPole) # 将之前的塔从中间柱子移到终点柱子，并将其放置到最大的盘子
                                                            # 基本情况是高度为0,move Tower函数直接返回--从moveTower返回才能调用moveDisk
def moveDisk(fp,tp):
    print("moving disk from %d to %d\n" % (fp,tp))   # 说明将盘子从一根柱子移到另一根柱子


# 显式保存柱子的状态--一个柱子对应一个栈

    
        