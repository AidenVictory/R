# 绘制一棵分形树
from turtle import *

def tree(branchLen,t):
    if branchLen > 5:
        t.forward(branchLen)  # 直走
        t.right(20)
        tree(branchLen-15,t)  # 小乌龟右转20度后，递归调用，画右子树
        t.left(40)
        tree(branchLen-10,t)  # 左转40度，抵消之前的右转20度，递归调用，画左子树
                              # 每一次递归调用，减去branchLen,使得递归树越来越小
        t.right(20)
        t.backward(branchLen) # 后退

def main():
    t = Turtle()                 # 树的每一次分支点都对应一次递归调用
    myWin  = t.getscreen()            # 程序先绘制右子树,一路到其最短的嫩枝
    t.left(90)                              # 反向回到树干，依次绘制完右子树
    t.up()                                      # 开始绘制左子树,左子树自己的右子树被完全画好之后,绘制最左端的嫩枝
    t.backward(300)
    t.down()
    t.color('green')
    tree(35,t)
    myWin.exitonclick()        

main()