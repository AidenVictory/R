# 
from turtle import *
 
myTurtle = Turtle()            # 创建一个turtle对象
myWin = myTurtle.getscreen()   # 创建用于绘制图案的窗口

def drawSpiral(myTurtle,lineLen):  
    if lineLen > 0 :                   # 基本情况：要画的线的长度lineLen降为0
        myTurtle.forward(lineLen)      # lineLen>0,则小乌龟向前移动lineLen个单位
        myTurtle.right(90)             # 然后向右旋转90度
        drawSpiral(myTurtle,lineLen-5) # 递归发生在用缩短的距离再一次调用drawSpiral函数

drawSpiral(myTurtle,100)
myWin.exitonclick()                    # 结尾调用myWin.exitonclick函数,使得小乌龟进入等待模式
                                       # 直到用户在窗口内再次点击,程序清理退出