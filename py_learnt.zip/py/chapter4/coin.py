# 硬币找零
def recMC(coinValueList,change):
    minCoins = change
    if change in coinValueList:       # 检查是否为基本情况--尝试用1枚硬币找零
        return 1                        
    else:
        for i in [c for c in coinValueList if c <= change]:    # 使用列表循环筛选出小于当前找零金额的硬币面值 
            numCoins = 1 + recMC(coinValueList,change-i)       # 递归调用--将找零金额减去所选的硬币面值， 并将所需的硬币数加1
            if numCoins < minCoins:
                minCoins = numCoins
    return minCoins
print(recMC([1,5,10,25],63)) 