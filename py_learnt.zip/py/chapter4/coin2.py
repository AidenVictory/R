# 添加查询表后的找零算法
def recDC(coinValueList,change,knownResults):
    minCoins = change
    if change in coinValueList:
        knownResults[change] = 1
        return 1
    elif knownResults[change] > 0:         # 检查查询表中是否已经有某个找零金额对应的最少硬币数
        return knownResults[change]        # 如果没有，就递归计算并且把得到的最少硬币数结果存在表中
    else:                                           
        for i in [c for c in coinValueList if c <= change]:
            numCoins = 1 + recDC(coinValueList,change - i,knownResults)
            if numCoins < minCoins:
                minCoins = numCoins
                knownResults[change] = minCoins
    return minCoins
recDC([1,5,10,25],63,[0]*63)    
         