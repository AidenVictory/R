# 用动态规划算法解决找零问题
# 该函数并非递归函数 
def dpMakeChange(coinValueList,change,minCoins,coinsUsed): # 接受三个参数--硬币面值列表\找零金额\由每一个找零金额所需的最少硬币数构成的列表(列表长度为金额数)
    for cents in range(change+1):
        coinCount = cents
        newCoin = 1
        for j in [c for c in coinValueList if c <= cents]:   # 该循环针对由cents指定的找零金额考虑所有可用的面值
            if minCoins[cents-j] + 1 < coinCount:             # 把最少的硬币数记录在minCoins表中
                coinCount = minCoins[cents-j] + 1
                newCoin = j                                   # 该循环从1分找零开始，然后系统地一直计算到所需的找零金额
        minCoins[cents] = coinCount
        coinsUsed[cents] = newCoin
    return minCoins[change]                                   # minCoins将包含找零金额从0到change的所有最优解--即这个范围内对应找零金额所需的最少硬币数
# 修改后的动态规划算法,扩展从表中回溯并打印所用硬币的printCoins的函数
def printCoins(coinsUsed,change):
    coin = change                                # coinUsed是一个列表,其中是用于找零的硬币
    while coin > 0:
        thisCoin = coinsUsed[coin]
        print(thisCoin)
        coin = coin - thisCoin                   # 
        
def main():
    # 处理硬币面值21分
    cl = [1,5,10,21,25]          
    coinsUsed = [0] * 64     # 列表,用于找零的硬币
    coinCount = [0] * 64     # 最少硬币数
    print(dpMakeChange(cl,63,coinCount,coinsUsed))
    printCoins(coinsUsed,63)
    printCoins(coinsUsed,52)
    print(coinsUsed)
    
main()
    
