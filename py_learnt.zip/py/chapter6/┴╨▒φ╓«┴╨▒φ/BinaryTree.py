def BinaryTree(r):           # 便于将列表作为树使用的函数
    return [r,[],[]]


def insertLeft(root,newBranch):       # 插入左子树
    t = root.pop(1) # 列表元素2
    if len(t) > 1:
        root.insert(1,[newBranch,t,[]])
    else:
        root.insert(1,[newBranch,[],[]])
    return root 

def insertRight(root,newBranch):      # 插入右子树
    t = root.pop(2)
    if len(t) > 1:
        root.insert(2,[newBranch,[],t])
    else:
        root.insert(2,[newBranch,[],[]])
    return root

def getRootVal(root):                 # 读取根节点 
    return root[0]

def setRootVal(root,newVal):          # 写根节点
    root[0] = newVal
    
def getLeftChild(root):               # 读取左子树
    return root[1]

def getRightChild(root):              # 读取右子树
    return root[2]

def main():
    r = BinaryTree(3)
    print(r)
    print(insertLeft(r,4))
    print(insertLeft(r,5))
    print(insertRight(r,6))
    print(insertRight(r,7))
    l = getLeftChild(r)
    print(l)
    setRootVal(l,9)
    print(r)
    print(insertLeft(l,11))
    print(r)
    print(getRightChild(getRightChild(r)))
    
main()
    
    