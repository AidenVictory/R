class BinarySearchTree:
    def __init__(self):
        self.root = None
        self.size = 0
    def length(self):
        return self.size
    def __iter__(self):
        return self.root.__iter__()
    
    def put(self,key,val):        # 检查树是否有根节点
        if self.root:
            self._put(key,val,self.root)   # 若有，则调用递归辅助函数
        else:
            self.root = TreeNode(key,val)  # 若没有，则创建一个TreeNode，并将其作为树的根节点
        self.size = self.size + 1
   
    def _put(self,key,val,currentNode):
        if key < currentNode.key :          # 比较新键与当前节点的键
            if currentNode.hasLeftChild():  # 新键更小，则搜索左子树
                self._put(key,val,currentNode.leftChild)
            else:                           # 没有可供搜索的左子节点，找到新键插入位置
                currentNode.leftChild = TreeNode(key,val,
                                                 parent = currentNode)  
                # 向树中插入一个节点，方法为创建一个TreeNode 对象，插入到前一步发现的位置 
        else:
            if currentNode.hasRightChild(): # 新键更大，搜索右子树
                self._put(key,val,currentNode,rightChild) 
            else:
                currentNode.rightChild = TreeNode(key,val,
                                                  parent = currentNode)
    def __setitem__(self,k,v):
        self.put(k,v)         
    
    # 查找键对应的值
    def get(self,key): 
        if self.root:
            res = self._get(key,self.root) # _get方法返回一个TreeNode给get
            if res :
                return res.payload
            else:
                return None
        else:
            return None
         
    def _get(self,key,currentNode): # 递归函数
        if not currentNode:
            return None 
        elif currentNode.key == key:
            return currentNode 
        elif key < currentNode.key:
            return self._get(key,currentNode.leftChild)
        else:
            return self._get(key,currentNode.rightChild)
        
    def __getitem__(self,key):
        return self.get(key)
    
    def __contains__(self,key):  # 检查树中是否含有某个键
        if self._get(key,self.root):  # 利用_get方法
            return True
        else:
            return False

    def delete(self,key):
        if self.size > 1:
            nodeToRemove = self._get(key,self.root) # 使用_get方法搜索,找到要移除的TreeNode
            if nodedToRemove:
                self.remove(nodeToRemove)
                self.size = self.size -1
            else:
                raise KeyError('Error,key not in tree') # 抛出异常
        elif self.size == 1 and self.root.key == key:   # 只有一个节点
            self.root = None 
            self.size = self.size - 1
        else:
            raise KeyError('Error,key not in tree')
        
    def __delitem__(self,key):
        self.delete(key)

    def remove(self,currentNode):
        if currentNode.isLeaf(): 
            # 情况1：待删除节点没有子节点--删除该节点，并移除父节点对该节点的引用
            if currentNode == currentNode.parent.leftChild:
                currentNode.parent.leftChild = None 
            else:
                currentNode.parent.rightChild = None 
        elif currentNode.hasBothChildren():
            # 情况2：待删除节点有两个子节点--寻找后继节点(可以替换待删除节点的节点)
            succ = currentNode.findSuccessor()
            succ.spliceOut()
            currentNode.key = succ.key 
            currentNode.payload = succ.payload 
        else: 
            # 情况3：只有一个子节点
            if currenNode.hasLeftChild():
                if currentNode.isLeftChild():
                    # 当前节点为左子节点
                    currentNode.leftChild.parent = currentNode.parent 
                    # 将当前节点的左子节点对父节点的引用改为指向当前节点的父节点
                    currentNode.parent.leftChild = currentNode.leftChild
                    ## 将父节点对当前节点的引用改为指向当前节点的左子节点
                elif currentNode.isRightChild():
                    # 当前节点为右子节点
                    currentNode.leftChild.parent = currentNode.parent 
                    # 将当前节点的右子节点对父节点的引用改为指向当前节点的父节点
                    currentNode.parent.rightchild = currentNode.leftChild
                    # 将父节点对当前节点的引用改为指向当前节点的右子节点
                else:
                    currentNode.replaceNodeData(currentNode.leftChild.key,
                                                currentNode.leftChild.payload,
                                                current.leftChild.leftChild,
                                                currentNode.leftChild.rightChild)
                    # 若该节点无父节点，则其为根节点。调用replaceNodeData方法，替换以上属性
            else:
                if currentNode.isLeftChild():
                    currentNode.rightChild.parent = currentNode.parent 
                    currentNode.parent.leftChild = currentNode.rightChild
                elif currentNode.isRightChild():
                    currentNode.rightChild.parent = currentNode.parent 
                    currentNode.parent.rightChild = currentNode.rightChild 
                else:
                    currentNode.replaceNodeData(currentNode.rightChild.key,
                                                currentNode.rightChild.payload,
                                                currentNode.rightChild.leftChild,
                                                currentNode.rightChild.rightChild)           
    # AVL树的实现
    def _put(self,key,val,currentNode):
        # 重载_put方法
        if key < currentNode.key:
            if currentNode.hasLeftChild():
                self._put(key,val,currentNode.leftChild)
            else:
                currentNode.leftChild = TreeNode(key,val,
                                                 parent = currentNode)
                self.updateBalance(currentNode.leftChild)
        else:
            if currentNode.hasRightChild():
                self._put(key,val,currentNode.rightChild)
            else:
                currentNode.rightChild = TreeNode(key,val,
                                                  parent = currentNode)
                self.updateBalance(currentNode.rightChild)
    def updateBalance(self,node):
        # 重写updateBalance辅助方法
        if node.balanceFactor > 1 or node.balanceFactor < -1:
            # 该方法首先检查--当前节点是否需要再平衡
            self.rebalance(node)
            return 
        if node.parent != None:
            # 父节点的平衡因子非零，就沿着树往根节点的方向递归调用updateBalance方法
            if node.isLeftChild():
                node.parent.balanceFactor += 1
            elif node.isRightChild():
                node.parent.balanceFactor -= 1
            if node.parent.balanceFactor != 0:
                self.updateBalance(node.parent)
    def rotateLeft(self,rotRoot):
        # 左旋让失衡的树再度平衡
        newRoot = rotRoot.rightChild            # 新根节点是旧根节点的右子节点
        # 创建一个临时变量，用于记录子树的新根节点
        rotRoot.rightChild = newRoot.leftChild
        # 将旧根节点的右子节点替换为新根节点的左子节点
        if newRoot.leftChild != None:
            # 如果新根节点有左子节点
            newRoot.leftChild.parent = rotRoot
            # 这个左子节点的新父节点就是旧根节点
        newRoot.parent = rotRoot.parent 
            # 将新根节点的父指针指向旧根节点的父节点 
        if rotRoot.isRoot():
            # 旧根节点是整棵树的根节点
            self.root = newRoot 
            # 将树的根节点设为新根节点
        else:
            if rotRoot.isLeftChild():
                # 当旧根节点是左子节点
                rotRoot.parent.leftChild = newRoot
                # 将左子节点的父指针指向新根节点 
            else: 
                # 当旧根节点是右子节点
                rotRoot.parent.rightChild = newRoot
                 # 将右子节点的父指针指向新根节点
        newRoot.leftChild = rotRoot 
        rotRoot.parent = newRoot 
        # 将旧根节点的父节点设为新根节点
        rotRoot.balanceFactor = rotRoot.balanceFactor + 1\
            - min(newRoot.balanceFactor,0)       # 更新旧根节点和新根节点的平衡因子
        newRoot.balanceFactor = newRoot.balanceFactor + 1\
            + max(rotRoot.balanceFactor,0)
    
    def rebalance(self,node):
        # 实现再平衡
        if node.balanceFactor < 0:
            # 子树需要左旋
            if node.rightChild.balanceFactor > 0:
                # 检查右子树的平衡因子，左倾则右旋
                self.rotateRight(node.rightChild)
                self.rotateLeft(node)
                # 再围绕原节点做一次左旋
            else:
                self.rotateLeft(node)
        # 规则1
        elif node.balanceFactor > 0:
            # 子树需要右旋
            if node.leftChild.balanceFactor < 0:
                # 检查左子树的平衡因子，右倾则左旋
                self.rotateLeft(node.leftChild)
                self.rotateRight(node)
                # 围绕原节点做一次右旋
            else:
                self.rotateRight(node)
                
        
class TreeNode:
    def __init__(self,key,val,left=None,right=None,
                 parent = None):
        self.key = key 
        self.payload = val 
        self.leftChild = left
        self.rightChild = parent
        
    def hasLeftChild(self):    
        return self.rightChild
    
    def hasRightChild(self):
        return self.rightChild
    
    def isLeftChild(self):
        return self.parent and \
            self.parent.rightChild == self
    
    def isRoot(self):
        return not self.parent
    
    def isLeaf(self): # 是否为叶子节点
        return not (self.rightChild or self.leftChild)
    
    def hasAnyChildren(self):
        return self.rightChild or self.leftChild
    
    def hasBothChildren(self):
        return self.rightChild and self.leftChild
    
    def replaceNodeData(self,key,value,lc,rc):
        self.key = key 
        self.payload = value
        self.leftChild = lc
        self.rightChild = rc
        if self.hasLeftChild():
            self.leftChild.parent = self 
        if self.hasRightChild():
            self.rightChild.parent = self
    
    # 寻找后继节点
    def findSuccessor(self):
        succ = None 
        if self.hasRightChild():
            succ = self.rightChild.findMin()
            # 节点有右子节点，后继节点为右子树最小节点
        else:
            if self.parent:
                if self.isLeftChild():
                    succ = self.parent 
                    # 节点无右子节点，本身为父节点的左子节点，后继节点为父节点
                else:
                    self.parent.rightChild = None 
                    succ = self.parent.findSuccessor()
                    self.parent.rightChild = self 
                    # 节点为父节点的右子节点，且本身无右子节点，后继节点为除其本身外父节点的后继节点
        return succ 
    
    def findMin(self): # 查找子树中最小的键 
        current = self 
        while current.hasLeftChild():
            current = current.leftChild
            # 沿着子树中每个节点的leftChild引用走，直到遇到一个没有左子节点的节点
        return current 
    
    def spliceOut(self):
        if self.isLeaf():
            if self.isLeftChild():
                self.parent.leftChild = None 
            else:
                self.parent.rightChild = None 
        elif self.hasAnyChildren():
            if self.hasLeftChild():
                if self.isLeftChild():
                    self.parent.leftChild = self.leftChild
                else:
                      self.parent.rightChild = self.leftChild
                self.leftChild.parent = self.parent 
            else:
                if self.isLeftChild():
                    self.parent.leftChild = self.rightChild
                else:
                    self.parent.rightChild = self.rightChild
                self.rightChild.parent = self.parent 
    # 二叉搜索树迭代器
    def __iter__(self):
        if self:
            if self.hasLeftChild():
                for elem in slef.leftChild:
                    yield elem 
            yield self.key
            if self.hasRightChild():
                for elem in self.rightChild:
                    yield elem 
                     