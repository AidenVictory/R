
def __init__(self):
    self.heapList = [0]    # 初始化列表 
    self.currentSize = 0   # 初始化属性--堆的当前大小

def percUp(self,i):        # 保持最小堆的有序性
    while i // 2 > 0:
        if seelf.heapList[i] < self.heapList[i//2]:
            tmp = self.heapList[i//2]
            self.heapList[i // 2] = self.heapList[i]
            self.heapList[i] = tmp
        i = i // 2

def insert(self,k):        # 向二叉堆中新加元素
    self.heapList.append(k)
    self.currentSize = self.currentSize + 1
    self.percUp(self.currentSize)
    
def perDown(self,i):       #  交换i号根节点与其最小子节点，至最底层
    while(i*2) <= self.currentSize:
        mc = self.minChild(i)
        if self.heapList[i] > self.heapList[mc]:
            tmp = self.heapList[i]
            self.heapList[i] = self.heapList[mc]
            self.heapList[mc] = tmp 
        i = mc 
 
def minChild(self,i):      # 返回i号父节点的最小子节点索引
    if i*2+1 >self.currentSize:
        return i * 2
    else:
        if self.heapList[i*2] < self.heapList[i*2+1]:
            return i * 2
        else:
            return i * 2 + 1

def delMin(self):          # 返回最小元素并删除
    retval = self.heapList[1]
    self.heapList[1] = self.heapList[self.currentSize]
    self.currentSize = self.currentSize -1  
    self.heapList.pop()
    self.percDown(1)
    return retval

def buildHeap(self,alist):  # 根据元素列表构建堆
    i = len(alist) // 2
    self.currentSize = len(alist)
    self.heapList = [0] + alist[:]
    while (i > 0):    # 从倒数第二层至第一层，每次重建堆至最底层
        self.percDown(i)
        i = i - 1
             