from pythonds.trees import BinaryTree
r = BinaryTree('a')
r.getRootVal()