# 从左到右读取一个括号串，然后判断其中的括号是否匹配
from pythonds.basic import Stack
def parChecker(symbolString):
    s = Stack()
    balanced = True 
    index = 0
    while index < len(symbolString) and balanced:
        symbol = symbolString[index] # 逐个读取括号串元素
        if symbol == "(":
            s.push(symbol)           # 将左括号存入栈中
        else:                        # 对于右括号，则删除相应数目的左括号数量
            if s.isEmpty():         
                balanced = False    
            else:
                s.pop()
        index = index + 1
    if balanced and s.isEmpty():
        return True
    else:
        return False
    
def main():
    print(parChecker(' '))
    
main()