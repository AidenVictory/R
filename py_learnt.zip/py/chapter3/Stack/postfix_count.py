## 计算后序表达式
from pythonds.basic import Stack
def postfixEval(postfixExpr):
    operandStack = Stack()
    
    tokenList = postfixExpr.split()            ## 将 postfix 分解成列表 -- 要求输入时必须空格
    
    for token in tokenList:                    
        if token in "0123456789":              
            operandStack.push(int(token))      # 将操作数存入栈中
        else:                                
            operand2 = operandStack.pop()      # 运算顺序与读取栈中元素顺序相反             
            operand1 = operandStack.pop()      
            result = doMath(token,operand1,operand2)
            operandStack.push(result)
            
    return operandStack.pop()
def doMath(op,op1,op2):                         # 定义运算符对应的操作数运算
    if op == "*":
        return op1 * op2
    elif op == "/":
        return op1 / op2
    elif op == "+":
        return op1 + op2
    else:
        return op1 - op2

def main():
    a = postfixEval("12 2 * 3 4 / + 5 -")
    print(a)
main()