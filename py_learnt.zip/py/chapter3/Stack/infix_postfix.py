## 中序表达式 (infix) 转化为后序表达式 (postfix)
from pythonds.basic import Stack
import string 

def infixToPostfix(infixexper):
    # 存储运算符的字典
    prec= {}
    prec['*'] = 3
    prec['/'] = 3
    prec['+'] = 2
    prec['-'] = 2
    prec['('] = 1
    
    opStack = Stack()
    postfixList = []
    
    tokenList = infixexper.split()          # 将字符串分解成列表 -- 默认按照空格分解 -- 故输入应满足空格要求
    for token in tokenList:
        if token in string.ascii_uppercase: # 26个大写字母--代表操作数
            postfixList.append(token) 
        elif token == '(':
            opStack.push(token)             # 将'('存入栈中
        elif token == ')':                  # 中序表达式转换为后序表达式
            topToken = opStack.pop()        # 取出并删除栈中的顶端元素
            while topToken != '(':
                postfixList.append(topToken)
                topToken = opStack.pop()
        else:
            while(not opStack.isEmpty()) and \
                (prec[opStack.peek()] >= prec[token]):
                    postfixList.append(opStack.pop())
            opStack.push(token)
    while not opStack.isEmpty():
        postfixList.append(opStack.pop())
    return " ".join(postfixList)    

        
        



def main():
    print(infixToPostfix('A * B + C / D - E'))     
    
main()
            
            
              