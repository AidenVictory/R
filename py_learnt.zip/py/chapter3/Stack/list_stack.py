## 用python列表实现栈
class Stack:
    def __init__(self): 
        self.items = [] 
    def isEmpty(self):
        return self.items == []
    def push(self,item):                      # 栈的元素添加
        self.items.append(item)               
    def pop(self):                            # 栈返回并删除栈顶端元素
        return self.items.pop()
    def peek(self):                           # 栈返回顶端元素
        return self.items[len(self.items)-1]
    def size(self):                           # 返回栈的元素个数
        return len(self.items)
def main():
    s = Stack()
    print(s.isEmpty())
    print(s.push(4))
    print(s.push('dog'))
    print(s.peek())
    print(s.push(True))
    print(s.size())
    print(s.pop())
    print(s.size())
    
main()
