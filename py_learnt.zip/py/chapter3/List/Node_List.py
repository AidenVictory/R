# 基于链表遍历技术,实现无序列表功能创建
class Node :
    def __init__(self,initdata):
        self.data = initdata       # 节点的数据变量
        self.next = None           # 指向下一个节点的引用 -- "将节点接地" 
        
    def getData(self):             # 节点的访问方法
        return self.data
    
    def getNext(self):             # 指向下一个节点引用的方法
        return self.next 
    
    def setData(self,newdata):     
        self.data = newdata
        
    def setNext(self,newnext):
        self.next = newnext

class UnorderedList:
    def __init__(self):
        self.head = None           
                                   
    def isEmpty(self):
        return self.head == None   #  检查列表头部元素是否为空 -- 对应列表是否为空
    
    def add(self,item):
        temp = Node(item)          # 列表添加元素,存放于节点对象 
        temp.setNext(self.head)    # 将新节点与已有的链表结构链接
        self.head = temp           # 修改头节点,指向新创建的节点

    def length(self):
        current = self.head        # 外部引用访问,初始化头部节点
        count = 0                  # 记录遍历元素个数
        while current != None:    
            count = count + 1      
            current = current.getNext()  # 更新外部引用为下个元素的链接引用
        return count
    
    def search(self,item):
        current = self.head
        found = False
        while current != None and not found:
            if current.getData() == item:   # 判断引用元素与查找对象是否一致
                found = True               
            else :
                current = current.getNext() 
        return found                       # 返回查找元素是否在列表中 - T or F
    def remove(self,item):
        current = self.head
        aft_current = current.getNext()
        if current.getData() == item:
            self.head = aft_current
        else:
            found = False 
            while not found:
                if aft_current.getData() == item:
                    aft_current.setNext(current.getNext())
                    found = True
                else :
                    aft_current = aft_current.getNext()
                    current = current.getNext()
    def remove1(self,item):
        current = self.head 
        previous = None
        found = False 
        while not found:
            if current.getData() == item:
                found = True 
            else:
                previous = current 
                current = current.getNext()
        if previous == None:
            self.head == current.getNext()
        else:
            previous.setNext(current.getNext())            # ？？？没有对列表本身进行删除操作，只是对外部引用进行修改
    
def main():
    u_list = UnorderedList()
    print(u_list.isEmpty())
    u_list.add(1) 
    u_list.add('dog')
    u_list.add(True)
    print(u_list.length())
    print(u_list.search(1))
    u_list.remove(1)
    print(u_list.search(1))
    u_list.remove1('dog')
    print(u_list.search('dog'))

    
main()
      
