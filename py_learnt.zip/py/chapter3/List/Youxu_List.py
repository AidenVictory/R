# 有序列表 search和add方法不同于无序列表，其他方法基本相同
class Node :
    def __init__(self,initdata):
        self.data = initdata       # 节点的数据变量
        self.next = None           # 指向下一个节点的引用 -- "将节点接地" 
        
    def getData(self):             # 节点的访问方法
        return self.data
    
    def getNext(self):             # 指向下一个节点引用的方法
        return self.next 
    
    def setData(self,newdata):     
        self.data = newdata
        
    def setNext(self,newnext):
        self.next = newnext
class OrderedList:
    def __inf__(self):
        self.head = None

    
    def search(self,item):
        current = False
        found = False
        stop = False
        while current != None and not found and not stop:
            if current.getData() == item:
                found = True
            else:
                if current.getData() > item:               # 增加布尔变量stop,若有序列表元素大于查找元素，则终止循环
                    stop = True 
                else:
                    current = current.getNext()
        return found
    def add(self,item):
        current = self.head
        previous = None
        stop = False 
        while current != None and not stop:
            if current.getData() > item:
                stop = True
            else:
                previous = current 
                current = current .getNext()
                
        temp = Node(item)
        if previous == None:
            temp.setNext(self.head)
            self.head = temp 
        else:
            temp.setNext(current)
            previous.setNext(temp)
            