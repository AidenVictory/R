# 使用“除以2”算法将下列值转换成二进制数。列出转换过程中的余数 17、45、96
from pythonds.basic import Stack
def BinaryNumber(number):
    binary_print = Stack()
    b = number 
    i = 0
    while b != 0:
        i = i + 1
        a = b%2
        b = int(b/2)

        binary_print.push(a)
    
    result = [] 
    while not binary_print.isEmpty():
        c = str(binary_print.pop())
        result.append(c)
    print(''.join(result))
def main():
    BinaryNumber(19)
main()
        
    
