# 使用完全括号法，将下列中序表达式转换成前序表达式。 (A + B) ＊(C + D) ＊(E + F)
# 通用的方法:将表达式先括号化 infix-prefix '('->下一个运算符, infix-postfix ')'->上一个运算符

# 获取乘除实体,获取括号实体
from pythonds.basic import Stack

def findNextEntity(lis):
    res = ''
    opStack = Stack()
    for i in lis:
        if i == '(':
            opStack.push(i)
        elif i == ')':
            opStack.pop()
        res += i 
        if opStack.isEmpty():
            break   
    if res == '':
        res = False 
    return res 

# 对乘除实体添加加减操作
def addParentheses(expr):       # 加括号,输入的expr字符串不能含有空格
    indexs = list()
    entities = list()
    
    i = 0
    while i<len(expr):
            if expr[i] in '*/':
                tmp = entities[len(entities)-1]                 
                entities.remove(tmp)
                nextent = findNextEntity(expr[i+1:])
                entities.append("("+tmp+expr[i]+nextent+")")          # 为乘除实体间的乘除运算加上括号   (A+B)*C -> ((A+B)*C) 
                i += (len(nextent)+1)
            elif expr[i] in "+-":
                indexs.append(expr[i])
                i += 1
            else:
                tmp = findNextEntity(expr[i:]) 
                entities.append(tmp)
                i += len(tmp)
    
    while len(entities) > 1:
        entities[0] = '(' + entities[0] + indexs[0] +entities[1] + ')' # 为+-的表达式逐层加上括号       A+B+C  
        indexs.remove(indexs[0])
        entities.remove(entities[1])
        
    return entities[0]

# 中序转前序
def infixToPrefix(infixexpr):
    infixexpr = addParentheses(infixexpr)  # 为中序表达式添加完整的括号
    result = []                                         
    indexstack = Stack()                     
    for i in range(len(infixexpr)):       
        if infixexpr[i] == "(":            # 将左括号的索引保留在一个栈中
            indexstack.push(i)             # 将结果列表中对应的中序表达式读取位置赋值为'_'
            result.append("_")
        elif infixexpr[i] in "+-*/":
            result.append("_")             # 为运算符的结果列表添加相应位置的'_'，保证'('的索引在结果列表中对应的位置不出错
          
            result[indexstack.pop()] = infixexpr[i]  # 非常巧妙--以左括号的索引做凭借，更换为对应的运算符
                                                     # 将中序表达式中距离该运算符最近的左括号，更换对应结果列表位置的'_'为该运算符
        elif infixexpr[i] == ")":          
            result.append("_")             # 与运算符的'_'的添加同理
        else:
            result.append(infixexpr[i])
    while(result.count("_")):              # 删除'_'
        result.remove("_")
    return " ".join(result)                # 合并字符串并返回值


# 中序转后序
def infixToPostfix(infixexpr):
    infixexpr = addParentheses(infixexpr)
    result = []
    indexstack = Stack()
    for i in range(len(infixexpr)):
        if infixexpr[i] == "(":
            result.append('_')
        elif infixexpr[i] in "+-*/":
            result.append('_')
            indexstack.push(infixexpr[i])       # 与中序转前序不同,这里中序的运算符被存入栈中,其取出的栈顶元素即放入读取到')'的位置
        elif infixexpr[i] == ')':
            result.append(indexstack.pop())
        else:
            result.append(infixexpr[i])
    while(result.count("_")):
        result.remove('_')
    return " ".join(result)
            

  

def main():
    print(findNextEntity('((A+B)+C)'))
    
    print(addParentheses("A+B*C+D"))

    print(infixToPrefix("A+B*C+D"))
    
    print(infixToPostfix("A+B*C+D"))
main()