## 打印机问题
# 定义类 打印机
class Printer: 
    def __init__(self,ppm):
        self.pagerate = ppm              # 初始化打印速度 -- 打印页数/分钟
        self.currentTask = None          
        self.timeRemaining = 0              
    def tick(self):                      # 减量计时
        if self.currentTask != None:     
            self.timeRemaining = self.timeRemaining - 1 # timeRemaining ?
            if self.timeRemaining <= 0:
                self.currentTask = None  # 任务完成将打印机置于 -- 空闲状态
    def busy(self):
        if self.currentTask != None:
            return True
        else :
            return False
    def startNext(self,newtask):
        self.currentTask = newtask
        self.timeRemaining = newtask.getPages()  * 60/self.pagerate    # timeRemaining 计算
# 定义类 Task类
import random
class Task :
    def __init__(self,time):            # 初始化1 时间戳：任务创建并放入打印队列时间
        self.timestamp = time           # 初始化2 任务页数
        self.pages = random.randrange(1,21)
    def getStamp(self):                 
        return self.timestamp
    def getPages(self):
        return self.pages
    def waitTime(self,currenttime):
        return currenttime - self.timestamp  # 计算等待时间 

# 主模拟程序
from pythonds.basic import Queue
import random
def simulation(numSeconds,pagesPerMinute):
    labprinter = Printer(pagesPerMinute)    # 创建Printer类,传递参数打印速度
    printQueue = Queue()                    # 队列模拟
    waitingtimes = []                         
    
    for currentSecond in range(numSeconds):
        if newPrintTask():                  # 每秒执行一次任务随机创建函数
            task = Task(currentSecond)      # 生成该时刻的任务 -- 任务生成变化
            printQueue.enqueue(task)        # 加入打印队列 -- 打印队列变化
        if (not labprinter.busy()) and \
            (not printQueue.isEmpty()):
                nexttask = printQueue.dequeue()      
                waitingtimes.append(\
                    nexttask.waitTime(currentSecond)) # 空闲开启下一任务，并传递开始时间
                labprinter.startNext(nexttask)        
        labprinter.tick()                   # 减量计时--打印机状态变化
        
    averageWait=sum(waitingtimes)/len(waitingtimes)
    print("Average Wait %6.2f secs %3d tasks remaining."\
        %(averageWait,printQueue.size()))
    
def newPrintTask():                          # 辅助函数 判断是否有新创建的打印任务
    num = random.randrange(1,181)            # 平均180s生成一个打印任务 -- 随机数模拟随机事件
    if num == 180 :
        return True
    else :
        return False
    
# Run
def main():
    for i in range(10):
        simulation(3600,5)
main()