# 用列表实现队列
class Queue:
    def __init__(self):
        self.items = []
    def isEmpty(self):
        return self.items == []
    def enqueue(self,item):               # 队列添加元素
        self.items.insert(0,item)         
    def size(self):
        return len(self.items)
    def dequeue(self):                    # 删除并返回队列元素 -- FIFO
        return self.items.pop()
def main():
    s = Queue()
    print(s.isEmpty())
    s.enqueue(1)
    s.enqueue('a')
    print(s.size())
    print(s.isEmpty())
    s.enqueue(True)
    print(s.dequeue())
main()
    
        