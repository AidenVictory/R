
## 传土豆,达到计数常量者出局,直到剩下最后一位

from pythonds.basic import Queue
def hotPotato(namelist,num):                              # 输入--名字列表与计数常量
    simqueue = Queue()
    for name in namelist:
        simqueue.enqueue(name)
    while simqueue.size() > 1:
        for i in range(num):
            simqueue.enqueue(simqueue.dequeue())           # 达到计数常量值前，传到者由队列首端移到队列尾端  
            
        simqueue.dequeue()                                 # 达到计数常量后,删除队列首端的元素
        
                                                           # 直到剩下最后一个元素
    return simqueue.dequeue()
 
def main():
     namelist = ['a','b','c']
     num = 7
     print(hotPotato(namelist,num))
     
main()
     