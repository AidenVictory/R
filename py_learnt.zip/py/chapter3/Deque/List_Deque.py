# 使用python列表构造双端队列  注意：后端为列表左端
class Deque:
    def __init__(self):
        self.items = [] 
    def isEmpty(self):
        return self.items == []
    def addFront(self,item):
        self.items.append(item)
    def addRear(self,item):
        self.items.insert(0,item)
    def size(self):
        return len(self.items)
    def removeRear(self):
        return self.items.pop(0)
    def removeFront(self):
        return self.items.pop()

def main():
    d = Deque()
    print(d.isEmpty())
    d.addFront('dog')
    d.addRear(4)
    print(d.size())
    d.addRear(True)
    print(d.removeRear())
    print(d.removeFront())
    print(d.size())
    
main()