# 使用双端队列构建回文检测器
from pythonds.basic import Deque
def palchecker(aString):
    chardeque = Deque()
    tokenList = aString.split()
    for ch in aString:                               # 对于字符串的读取
        chardeque.addRear(ch)
    stillEqual = True
    
    while chardeque.size() > 1 and stillEqual:       # 双端队列元素>=2，则执行判断
        first = chardeque.removeFront()              
        last = chardeque.removeRear()
        if first != last:
            stillEqual = False
        
    return stillEqual
    
def main():
    a = 'madam'
    print(palchecker(a))
    b = 'size'
    print(palchecker(b))
    
main()