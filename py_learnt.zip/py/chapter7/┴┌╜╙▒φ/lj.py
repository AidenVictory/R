# Vertex类
class Vertex:
    def __init__(self,key):
        # 初始化id，以及字典connectedTo
        self.id = key 
        self.connectedTo = {} 
    
    def addNeighbor(self,nbr,weight = 0):
        # addNeighbor方法添加从一个顶点到另一个的连接
        self.connectedTo[nbr] = weight
        
    def __str__(self):
        return str(self.id) + 'connectedTo:' + str( [x.id for x in self.connectedTo])
                    
    def getConnections(self):
        # getConnections方法返回邻接表中的所有顶点
        return self.connectedTo.keys()
    
    def getId(self):
        return self.id 
    
    def getWeight(self,nbr):
        # getWeight方法返回从当前顶点到以参数传入的顶点之间的边的权重
        return self.connectedTo[nbr]
    
# Graph类
class Graph:
    def __init__(self):
        self.vertList = {}
        self.numVertices = 0
    
    def addVertex(self,key):
        self.numVertices = self.numVertices + 1
        newVertex = Vertex(key)
        self.vertList[key] = newVertex
        return newVertex
    
    def getVertex(self,n):
        if n in self.vertList:
            return self.vertList[n]
        else:
            return None 
        
    def __contains__(self,n):
        return n in self.vertList
    
    def addEdge(self,f,t,cost=0):
        if f not in self.vertList:
            nv = self.addVertex(f)
        if t not in self.vertList:
            nv = self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t],cost)
        
    def getVertices(self):
        # 返回图中所有顶点的名字
        return self.vertList.keys()
    
    def __iter__(self):
        # 遍历图中的所有顶点对象
        return iter(self.vertList.values())
     
def main():
    g = Graph()
    for i in range(6):
        # 创建6个顶点，依次编号为0~5
        g.addVertex(i)  # 对于每一个键，都创建了一个Vertex实例
    print(g.vertList)  # 打印顶点字典
    # 添加将顶点连接1起来的边
    g.addEdge(0,1,5)
    g.addEdge(0,5,2)
    g.addEdge(1,2,4)
    g.addEdge(2,3,9)
    g.addEdge(3,4,7)
    g.addEdge(3,5,3)
    g.addEdge(4,0,1)
    g.addEdge(5,4,8)
    g.addEdge(5,2,1)
    # 用一个嵌套循环验证图中的每一条边都已被正确储存
    for v in g:
        for w in v.getConnections():
            print("(%s,%s)"%(v.getId(),w.getId()))

main()     