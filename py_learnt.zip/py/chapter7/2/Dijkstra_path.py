# Dijkstra算法的python实现
from pythonds.graphs import PriorityQueue,Graph,Vertex
def dijkstra(aGraph,start):
    pq = PriorityQueue()
    # 使用优先级队列 PriorityQueue类存储了键值对的二元组
    start.setDistance(0)
    pq.buildHeap([(v.getDistance(),v) for v in aGraph])
    # 使用顶点的距离作为优先级--希望访问距离最小的顶点
    while not pq.isEmpty():
        for nextVert in currentVert.getConnections():
            newDist = currentVert.getDistance() \
                + currentVert.getWeight(newVert)
            if newDist < nextVert.getDistance():
                nextVert.setDistance(newDist)
                newVert.setPred(currentVert)
                pq.decreaseKey(nextVert,newDist)
                # 增加decreaseKey方法
                # 当到一个顶点的距离减少并且该顶点已经在优先级队列中，
                # 调用该方法，将该顶点移向优先级队列的头部
                