# Vertex类
class Vertex:
    def __init__(self,key):
        # 初始化id，以及字典connectedTo
        self.id = key 
        self.connectedTo = {} 
    
    def addNeighbor(self,nbr,weight = 0):
        # addNeighbor方法添加从一个顶点到另一个的连接
        self.connectedTo[nbr] = weight
        
    def __str__(self):
        return str(self.id) + 'connectedTo:' + str( [x.id for x in self.connectedTo])
                    
    def getConnections(self):
        # getConnections方法返回邻接表中的所有顶点
        return self.connectedTo.keys()
    
    def getId(self):
        return self.id 
    
    def getWeight(self,nbr):
        # getWeight方法返回从当前顶点到以参数传入的顶点之间的边的权重
        return self.connectedTo[nbr]
    
# Graph类
class Graph:
    def __init__(self):
        self.vertList = {}
        self.numVertices = 0
    
    def addVertex(self,key):
        self.numVertices = self.numVertices + 1
        newVertex = Vertex(key)
        self.vertList[key] = newVertex
        return newVertex
    
    def getVertex(self,n):
        if n in self.vertList:
            return self.vertList[n]
        else:
            return None 
        
    def __contains__(self,n):
        return n in self.vertList
    
    def addEdge(self,f,t,cost=0):
        if f not in self.vertList:
            nv = self.addVertex(f)
        if t not in self.vertList:
            nv = self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t],cost)
        
    def getVertices(self):
        # 返回图中所有顶点的名字
        return self.vertList.keys()
    
    def __iter__(self):
        # 遍历图中的所有顶点对象
        return iter(self.vertList.values())
     
