# Prim算法的python实现
from pythonds.graphs import PriorityQueue,Graph,Vertex
def prim(G,start):
    pq = PriorityQueue()
    # 使用优先级队列选择下一个添加到图中的顶点
    for v in G:
        v.setDistance(sys.maxsize)
        # 将起点到其他所有顶点的距离都初始化为无穷大
        v.setPred(None) 
    start.setDistance(0)
    # 起点到自己的距离为0
    pq.buildHeap([(v.getDistance(),v) for v in G])
    while not pq.isEmpty():
        currentVert = pq.delMin()
        for nextVert in currentVert.getConnections():
            newCost = currentVert.getWeight(nextVert) \
                + currentVert.getDistance()
            if v in pq and newCost < nextVert.getDistance():
                nextVert.setPred(currentVert)
                nextVert.setDistance(newCost)
                pq.decreaseKey(nextVert,newCost)
                # 调用decreaseKey方法，将该顶点移向队列的头部
                