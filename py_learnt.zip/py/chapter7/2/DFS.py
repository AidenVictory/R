from pythonds.graphs import Graph
# 将代码作为Graph类的一个子类中的方法来实现
class DFSGraph(Graph):
    # 该实现继承Graph类
    def __init__(self):
        super().__init__()
        self.time = 0
        # 增加time实例变量，以及如下两个方法
    
    def dfs(self):
        for aVertex in self:
            # 遍历所有顶点
            aVertex.setColor('white')
            aVertex.setPred(-1)
        for aVertex in self:
            if aVertex.getColor() == 'white':
                self.dfsvisit(aVertex)
                # 对白色顶点调用dfsvisit方法
                
    def dfsvisit(self,startvertex):
        startVertex.setColor('gray')
        self.time += 1
        statVertex.setDiscovery(self.time)
        for nextVertex in startVertex.getConnections():
            if nextVertex.getColor() == 'white':
                nextVertex.setPred(startVertex)
                self.dfsvisit(nextVertex)
        startVertex.setColor('black')
        self.time += 1
        self.time += 1
        startVertex.setFinish(self.time)
        