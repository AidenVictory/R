# 宽度优先搜索
from pythonds.graphs import Graph,Vertex
# 使用Vertex类的扩展版本,新增3个实例变量--distance,predecessor,color\
    # 每一个变量都有对应的getter方法和setter方法
from pythonds.basic import Queue 
def bfs(g,start):
    start.setDistance(0)
    # BFS从起点s开始，将它标记为灰色(表示正在访问它) 
    start.setPred(None)
    # distance和predecessor两个变量，分别初始化为0和None
    vertQueue = Queue() 
    # 使用Queue来决定后续要访问的顶点
    vertQueue.enqueue(start)
    # start被放入Queue中 
    while (vertQueue.size() > 0):
        currentVert = vertQueue.dequeue()
        # 系统化地访问位于队列头部的顶点
        for nbr in currentVert.getConnections():
            # 遍历邻接表来访问新的顶点
            if (nbr.getColor() == 'white'):
                # 检查颜色，若为白色，说明未被访问
                nbr.setColor('gray')
                # 将新的未访问顶点nbr标记为灰色
                nbr.setDistance(currentVert.getDistance() + 1)
                # 将nbr的distance设置成到currentVert的distance加1
                nbr.setPred(currentVert)
                # 将nbr的predecessor设置成当前顶点currentVert
                vertQueue.enqueue(nbr)
                # 将nbr添加到队列的尾部
        currentVert.setColor('balack')

# 回溯宽度优先搜索树
def traverse(y):
    x = y
    while(x.getPred()):
        print(x.getId())
        x = x.getPred()
    print(x.getId())
traverse(g.getVerttex('sage'))