from pythonds.graphs import Graph
def knightGraph(bdSize):
    ktGraph = Graph()
    for row in range(bdSize):
        for col in range(bdSize):
            nodeId = posToNodeId(row,col,bdSize)
            newPositions = genLegalMoves(row,col,bdSize)
            # 访问棋盘上每一格时，都会调用辅助函数genLegalMoves来创建一个列表
            # 用以记录从这一格开始的所有合理走法        
            for e in newPositions:
                nid = posToNodeId(e[0],e[1])
                # 另外一个辅助函数posToNodeld将棋盘上的行列位置转换为与图中定点编号相似的线性顶点数
                ktGraph.addEdge(nodeId,nid)
                # 所有的合理走法都被转换成图中的边
    return ktGraph

def genLegalMoves(x,y,bdSize):
    # genLegalMoves函数接受骑士在棋盘上的位置，并生成8种可能的走法
    newMoves = []
    moveOffsets = [(-1,-2),(-1,2),(-2,-1),(-2,1),
                   (1,-2),(1,2),(2,-1),(2,1)]
    for i in moveOffsets:
        newX = x + i[0]
        newY = Y + i[1]
        if legalCoord(newX,bdSize) and \
            legalCoord(newY,bdSize):
                newMoves.append((newX,newY))
    return newMoves 

def lefalCoord(x,bdSize):
    # legalCoord辅助函数确认走法是合理的
    if x >= 0 and x < bdSize:
        return True 
    else:
        return False
    
from pythonds.graphs import Graph,Vertex
def knightTour(n,path,u,limit):
    # n--搜索树的当前深度，path--到当前为止访问过的顶点列表
    # u--希望在图中访问过的顶点,limit--路径上的顶点总数
    u.setColor('gray')
    # 记录--已被访问过的顶点为灰色
    path.append(u)
    if n < limit:
        nbrList = list(u.getConnections())
        i = 0
        done = False 
        while i < len(nbrList) and not done:
            if nbrList[i].getColor() == 'white':
                done = knightTour(n+1,
                                  path,
                                  nbrList[i],
                                  limit)
                # 递归调用knightTour函数
            i = i + 1
        if not done: # 准备回溯
            path.pop()
            u.setColor('white')
        else:
            done = True 
        return True 

def orderByAvail(n):
    # orderByAvail函数用于替换knightTour函数中的u.getConnections调用
    resList = []
    for v in n.getConnections():
        if v.getColor() == 'white':
            c = 0
            for w in v.getConnections():
                if w.getColor() == 'white':
                    c = c + 1
            resList.append((c,v))
    resList.sort(key = lambda x: x[0])
    return [y[1] for y in resList]

    