# 冒泡排序
def bubbleSort(alist):
    for passnum in range(len(alist)-1,0,-1):
        for i in range(passnum):
            if alist[i] > alist[i+1]:
                temp = alist[i]
                alist[i] = alist[i+1]
                alist[i+1] = temp
   
# 改进后的冒泡排序
def shortBubbleSort(alist):
    exchanges = True 
    passnum = len(alist) - 1
    while passnum > 0 and exchanges:     # 增加exchanges的判断,判断在一轮遍历中没有发生元素交换，就可以确定列表已经有序
        exchanges = False 
        for i in range(passnum): 
            if alist[i] > alist[i+1]:
                exchanges = True
                temp = alist[i]
                alist[i] = alist[i+1]
                alist[i+1] = temp 
        passnum = passnum -1
                
            