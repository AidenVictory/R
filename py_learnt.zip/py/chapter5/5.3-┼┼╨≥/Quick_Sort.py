def quickSort(alist):
    quickSortHelper(alist,0,len(alist)-1) # 调用递归函数
    
def quickSortHelper(alist,first,last):
    if first < last:
        
        splitpoint = partition(alist,first,last)
        
        quickSortHelper(alist,first,splitpoint-1) # 左区
        quickSortHelper(alist,splitpoint+1,last)  # 右区
        
def partition(alist,first,last):    # 分区函数
    pivotvalue = alist[first] # 基准值
    
    leftmark = first + 1
    rightmark = last
    done = False 
    while not done:
        
        while leftmark <= rightmark and \
            alist[leftmark] <= pivotvalue:
                leftmark = leftmark + 1      # 直到大于基准值
            
        while alist[rightmark] >= pivotvalue and \
            rightmark >= leftmark:           # 直到小于基准值
                rightmark = rightmark -1
        
        if rightmark < leftmark:
            done = True
        else:
            temp = alist[leftmark]
            alist[leftmark] = alist[rightmark]  # 交换
            alist[rightmark] = temp
            
    temp = alist[first]
    alist[first] = alist[rightmark]
    alist[rightmark] = temp                   # 将基准值置于 终止的rightmark,以左部均小于基准值,右部反之
    
    return rightmark

['a', ['b', ['d', [], []], ['e', [], []]], ['c', ['f', [], []], []]]