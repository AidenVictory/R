# 映射抽象数据类型
class   HashTable:
    def __init__(self):
        self.size = 11  # 散列表初始大小素数，可提高冲突处理算法的效率
        self.slots = [None] * self.size   # slots列表存储键
        self.data = [None] * self.size    # data列表存储值  
                                          # 键值一一对应
                                            
    def put(self,key,data):
        hashvalue = self.hashfunction(key,len(self.slots))
        
        if self.slots[hashvalue] == None:
            self.slots[hashvalue] = key
            self.data[hashvalue] = data
        else:
            if self.slots[hashvalue] == key:                       # 除非键已经在self.slots中,否则总是可以分配一个空槽
                self.data[hashvalue] = data # 替换                  
            else:
                nextslot = self.rehash(hashvalue,len(self.slots))      
                while self.slots[nextslot] != None:
                        # and self.slots[nextslot] != key:                 # 这里为什么需要一个判定是否为其键值的函数呢
                        nextslot = self.rehash(nextslot,len(self.slots))

                if self.slots[nextslot] == None:
                    self.slots[nextslot] = key
                    self.data[nextslot] = data
                
                else:
                    self.data[nextslot] = data # 替换

    def hashfunction(self,key,size):     # 简单的取余函数
        return key%size                

    def rehash(self,oldhash,size):       # 处理冲突,采用"加1"再散列函数的线性检测法
        return (oldhash +1)%size
    
    def get(self,key):                   
        startslot = self.hashfunction(key,len(self.slots))
        
        data = None
        stop = False
        found = False
        position = startslot
        while self.slots[position] != None and \
            not found and not stop:
                if self.slots[position] == key:
                    found = True
                    data = self.data[position]
                else:
                    position = self.rehash(position,len(self.slots))
                    if position == startslot:                # 确保搜索一定能结束,因为不会回到初始槽
                        stop = True
        return data
    def __getitem__(self,key):
        return self.get(key)

    def __setitem__(self,key,data):
        self.put(key,data)    
def main():
    H = HashTable()
    H[54] = 'cat'
    H[26] = 'dog'
    H[93] = 'lion'
    H[17] = 'tiger'
    H[77] = 'bird'
    H[31] = 'cow'
    H[44] = 'goat'
    H[55] = 'pig'
    H[20] = 'chicken'
    print(H.slots)
    print(H.data)
    
main()