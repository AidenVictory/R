# 无序列表的顺序搜索
def sequentialSearch(alist,item): # 接受列表与目标元素作为参数
    pos = 0
    found = False
    
    while pos < len(alist) and not found:
        if alist[pos] == item:
            found = True
        else:
            pos = pos +1 
    return found                    # 返回一个表示目标元素是否存在的布尔值

def main():
    a = [1,2,3,4]
    print(sequentialSearch(a,2))
    
main()