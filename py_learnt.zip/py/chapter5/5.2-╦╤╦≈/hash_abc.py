# 基于字符的元素(比如字符串)创建散列函数
def hash(astring,tablesize):  # 传入一个字符串和散列表的大小
    sum = 0
    for pos in range(len(astring)):
        sum = sum + ord(astring[pos]) * pos   # 用字符位置作为权重因子--避免异序词bug    
                                                       # 散列函数一定要高效
    return sum%tablesize      # 返回对应于槽容量的值
