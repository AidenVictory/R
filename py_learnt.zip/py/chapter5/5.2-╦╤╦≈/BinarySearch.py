# 有序列表的二分搜素
def binarySearch(alist,item):
    first = 0
    last = len(alist) - 1
    found = False
    
    while first <= last and not found:                    # 分治策略--将问题分解成小问题，以某种方式解决小问题，整合结果--解决最初的问题
        midpoint = (first + last) // 2
        if alist[midpoint] == item:
            found = True          
        else:
            if item < alist[midpoint] :                   # 二分 -- 针对一个更小的列表调用二分搜素函数
                last = midpoint -1
            else :
                first = midpoint + 1
    return found

# 二分搜索的递归版本
def binarySearch2(alist,item):
    if len(alist) == 0:
        return False
    else:
        midpoint = len(alist) // 2
        if alist[midpoint] == item:
            return True
        else:
            if item < alist[midpoint]:                               # 针对一个更小的列表调用二分搜索函数
                return binarySearch(alist[:midpoint],item)   # 使用切片运算符得到列表的左半部分，并将其传给下一次调用
            else:
                return binarySearch(alist[midpoint+1:],item)   

def main():
    a = [1,2,3,4,6,7,8]
    print(binarySearch2(a,2))
    print(binarySearch2(a,7))
    print(binarySearch2(a,5))
main()