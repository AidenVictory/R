# 有序列表的顺序搜索
def orderedSequentialSearch(alist,item):
    pos = 0
    found = False
    stop = False
    while pos < len(alist) and not found and not stop:
        if alist[pos] == item:
            found = True
        else :
            if alist[pos] > item :                   # 相比于无序列表,如果不存在目标元素,则搜算效率就会提高--因为遇到大于它的元素之后，其后的元素均不可比较
                stop = True
            else:
                pos = pos +1
    return found
def main():
    a = [1,2,3,5,6,7]
    print(orderedSequentialSearch(a,4))
main()