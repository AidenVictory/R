from xn_modp import *
import random
def RSAgenKeys(p,q):
    # 该函数根据p,q创建一个公钥和私钥
    n = p * q
    pqminus = (p-1) * (q-1)
    e = int(random.random() * n)
    while gcd(pqminus,e) != 1:
        e = int(random.random() * n)
    d,a,b = ext_gcd(pqminus,e)
    if b < 0:
        d = pqminus + b 
    else:
        d = b 
    return ((e,d,n))

def RSAencrypt(m,e,n):
    # 该函数接受一段消息、公钥和n，并返回密文
    chunks = toChunks(m,n.bit_length() // 8 *2)
    encList = []
    for messChunk in chunks:
        c = modexp(messChunk,e,n)
        encList.append(c)
    return encList 

def RSAdecrypt(chunkList,d,n):
    # 该函数接受密文、私钥和n，返回原始消息
    rList = []
    for c in chunkList:
        m = modexp(c,d,n)
        rList.append(m)
    return chunksToPlain(rList,n.bit_length() // 8 *2)

# chunksToPlain和toChunks函数--将字符串转换为数字块列表
# 必须确保字符对应的十六进制数一直是两位，这意味着有时需要补0
def toChunks(m,chunkSize):
    byteMess = bytes(m,'utf-8')
    # byteMess内置的decode函数将字节数转换为字符串
    hexString = ''
    for b in byteMess:
        hexString = hexString + ("%02x" % b)
        # 用字符串格式化表达式‘%02x' % b 轻松搞定--补零
    numChunks = len(hexString) // chunkSize
    # 根据整条消息得到一个长的十六进制字符串，可将长串切分为
    # numChunks个十六进制数块
    chunkList = []
    for i in range(0,numChunks*chunkSize+1,chunkSize):
        chunkList.append(hexString[i:i+chunkSize])
    chunkList = [eval('0x'+x) for x in chunkList if x]
    # 用eval函数和列表解析式将每个十六进制数转换为整数
    return chunkList 

def chunksToPlain(clist,chunkSize):
    hexList = []
    for c in clist:
        hexString = hex(c)[2:]
        clen = len(hexString) 
        hexList.append('0' * ((chunkSize - clen) % 2)
                       + hexString)
        # 块表示的数字可能明显小于原始的数字
        # 这种情况下需要补零，确保所有块在拼接时是等长的
        # 通过'0'*((chunkSize-clen) %2)把0前置，chunkSize是字符串中应有的位数，clen为实际位数
    hstring = "".join(hexList)
    messArray = bytearray.fromhex(hstring)
    return messArray.decode('utf-8') 

def main():
    e,d,n = RSAgenKeys(5563,8191)
    c = RSAencrypt('goodbye girl',e,n)
   
    m = RSAdecrypt(c,d,n)
    print(m)
    
main()