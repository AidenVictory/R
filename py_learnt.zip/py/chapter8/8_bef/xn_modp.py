# x^n(mod p)的递归定义
def modexp(x,n,p):
    if n == 0:
        return 1
    t = (x*x) % p
 
    tmp = modexp(t,n//2,p) 
    if n%2 != 0:
        tmp = (tmp * x) % p
    print(tmp)
    return tmp

def main():
    modexp(3,5,10)

main()

# 利用欧几里得算法求最大公因数
# def gcd(a,b):
#     if b == 0:
#         reurn a
#     elif a < b:
#         return gcd(b,a)
#     else:
#         return gcd(a-b,b)

# 改良后的欧几里得算法
def gcd(a,b):
    if b == 0:
        return a  
    else:
        return gcd(b,a%b)

# 扩展gcd函数
def ext_gcd(x,y):
    if y == 0:
        return (x,1,0)
    else:
        (d,a,b) = ext_gcd(y,x%y)
        return(d,b,a-(x//y)*b)