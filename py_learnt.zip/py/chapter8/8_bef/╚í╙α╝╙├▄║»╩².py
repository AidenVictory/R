# 简单1的取余加密函数
def encrypt(m): 
    # "凯撒密码"的加密形式，又叫rot13
    s = 'abcdefghijklmnopqrstuvwxyz'
    n = ''
    for i in m:
        j = (s.find(i)+13) % 26
        n = n + s[j]
    return n

# 以轮换数作为参数的解密函数 
def decrypt(m,k):
    s = 'abcdefghijklmnopqrstuvwxyz'
    n = ''
    for i in m:
        j = (s.find(i)+26-k) % 26
        n = n + s[j]
    return n 

def main():
    print(encrypt("uryybjbeyq"))
    print(decrypt('helloworld',13))
main()