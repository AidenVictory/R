from random import randrange
class HeaderNode:
    def __init__(self):
        self.next = None 
        self.down = None 
        # 头节点由next和down两个引用构成，构造方法初始化为None
    
    def getnext(self):
        return self.next 
    
    def getDown(self):
        return self.down 
    
    def setNext(self,newnext):
        self.next = newnext 
        
    def setDown(self,newdown):
        self.down = newdown  
        
class DataNode:
    def __init__(self,key,value):
        self.key = key 
        self.data = value 
        self.next = None 
        self.down = None 
    # 数据节点有4个字段--键、值以及next和down两个引用
    
    def getKey(self):
        return self.key 
    
    def getData(self):
        return self.data 
    
    def getNext(self):
        return self.next 
    
    def getDown(self):
        return self.down 
    
    def setData(self,newdata):
        self.data = newdata 
        
    def setNext(self,newnext):
        self.next = newnext 
        
    def setDown(self,newdown):
        self.down = newdown 

class SkipList:
    # 跳表的构造方法
    def __init__(self):
        self.head = None 
        # 没有头节点,表头设为None
        # s随着键-值对的加入，表头指向第一个头节点
        # 通过这个头节点，既可以访问数据节点链表，也可以访问更低的层
    
    def search(self,key): 
        # 在跳表中搜索键
        current = self.head
        # 搜索从表头开始
        found = False  # 直到找到键盘
        stop = False   # 或者检查完所有的数据节点
        while not found and not stop:
            if current == None:
                stop = True 
            else:
                if current.getNext() == None:
                    # 从顶层的头节点开始往右查找
                    current = current.getDown()
                    # 如果没有数据节点，就下降一层
                else:
                    if current.getnext().getKey() == key:
                        found = True 
                        # 如果有数据节点，则比较键的大小--匹配则搜索成功
                    else:
                        if key < current.getNext().getKey():
                            # 每一层是一个有序链表
                            # 若目标键小于数据节点中的键，则说明这一层不会有包含目标键的数据节点，因为往右的所有节点只会更大
                            current = current.getDown()
                            # 此时需要下降一层
                        else:
                            current = current.getNext()
                            # 只要当前层的节点有比目标键更小的键，就往下一个节点移动 
        if found:
            return current.getNext().getData() 
        else:
            return None 
    
    def insert(self,key,data):
    # 往跳表中加入键-值对
        if self.head == None:
            # 如果在表头添加节点，必须新建头节点和数据节点
            self.head = HeaderNode()
            temp = DataNode(key,data)
            self.head.setNext(temp)
            top = temp 
            while flip() == 1:
                # 重复循环，直到flip方法返回1(得到硬币的正面)
                newhead = HeaderNode()
                temp = DataNode(key,data)
                temp.setDown(top)
                # 每新加一层，都创建一个数据节点和头节点
                newhead.setNext(temp)
                newhead.setDown(self.head)
                self.head = newhead
                top = temp 
        else:
            # 对于非空跳表，需要搜索插入位置
            towerStack = Stack()
            # 没法知道塔中会有多少个数据节点，因此需要为每一层都保存插入点
            # 这些插入点会按逆序处理，所以栈可以很好地帮助我们按照与插入节点相反的顺序遍历链表
            current = self.head
            stop = False 
            while not stop:
                if current == None:
                    stop = True 
                else:
                    if current.getNext() == None:
                        towerStack.push(current)
                        current = current.getDown()
                    else:
                        current = current.getNext() 
            lowestLevel = towerStack.pop()
            temp = DataNode(key,data)
            temp.setNext(lowestLevel.getNext())
            lowestLevel.setNext(temp)
            top = temp 
            while flip() == 1:
                if towerStack.isEmpty():
                    # 只有栈为空之后，才需要返回并新建头节点
                    newhead = HeaderNode()
                    temp = DataNode(key,data)
                    temp.setDown(top)
                    newhead.setNext(temp)
                    newhead.setDown(self.head)
                    self.head = newhead 
                    top = temp 
                else:
                    nextLevel = towerStack.pop() 
                    # 从插入栈弹出下一个插入点
                    temp = DataNode(key,data)
                    temp.setDown(top)
                    temp.setNext(nextLevel.getNext())
                    nextLevel.setNext(temp)
                    top = temp 

class Map:
    # 构建映射--用跳表实现Map类
    def __init__(self):
        self.collection = SkipList()       # 构建一个内部跳表
        
    def put(self,key,value):
        self.collection.insert(key,value)  # 使用已经实现的insert方法
        
    def get(self,key):
        return self.collection.search(key) # 利用已经实现的insert方法和search方法
    
                         
            
        
    