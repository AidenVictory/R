# 使用数组实现列表
class ArrayList:
    def __init__(self):
        self.sizeExponent = 0
        self.maxSize = 0
        # 实例变量1--maxSize记录当前数组的大小
        self.lastIndex = 0
        # 实例变量2--lastIndex记录当前列表的末尾 
        self.myArray = []
        # 使用列表来模拟数组
    
    def append(self,val):
        if self.lastIndex > self.maxSize - 1:
            self.__resize()
        self.myArray[self.lastIndex] = val 
        self.lastIndex += 1
        
    def __resize(self):
        newsize = 2 ** self.sizeExponent
        # 计算新的数组大小
        print("newsize = ",newsize)
        newarray = [0] * newsize 
        for i in range(self.maxSize):
            # 分配新数组后，将旧列表中的值复制到新数组中
            newarray[i] = self.myArray[i]
        
        self.maxSize = newsize 
        # 更新maxSize和lastIndex
        self.myArray = newarray 
        # 将newarray保存为self.myArray
        self.sizeExponent += 1
        # 增加sizeExponent 
    
    # 索引操作  
    def __getitem__(self,idx):
        if idx < self.lastIndex:
            return self.myArray[idx]
        else:
            raise lookupError('index out of bounds')

    def __setitem__(self,idx,val):
        if idx < self.lastIndex:
            self.myArray[idx] = val 
        else:
            raise LookupError('index out of bounds')
        
    # 插入操作
    def insert(self,idx,val):
        if self.lastIndex > self.maxSize - 1:
            self.__resize()
        for i in range(self.lastIndex,idx-1,-1):
            self.myArray[i+1] = self.myArray[i]
            # 从最后一个元素开始，依次将最后一个元素复制到末尾
        self.lastIndex += 1
        self.myArray[idx] = val 
        
        
