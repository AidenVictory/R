# 简单的模式匹配器
def simpleMather(pattern,text):
    starti = 0  # 记录每次尝试的起点
    i = 0       # 文本的下标
    j = 0       # 模式的下标
    match = False 
    stop = False 
    # 控制匹配终止的两个条件--两个布尔型变量
    while not match and not stop:
        if text[i] == pattern[j]:
            i = i + 1
            j = j + 1
            # 若匹配，则两个下标都递增
        else:
            starti = starti + 1 # 向右移动
            i = starti
            j = 0 
            # 若不匹配，则移动到文本中下一个位置，将模式重置到起始位置
        if j == len(pattern):
            # 检查是否已处理完模式中所有字母
            match = True 
            # 是，则说明匹配成功
        else:
            # 不是，检查文本中是否还有字母
            if i == len(text):
                stop = True 
                # 穷尽文本而不得，则stop设置为True            
    if match:
        return i-j 
    #若匹配则返回字串在文本中的起始位置
    else:
        return -1
    # 若匹配失败,则返回-1


def mismatchLinks(pattern):
    augPattern = "0"+pattern
    # 先扩展模式，让模式中的下标对的上KMP图中的顶点标签
    links = {}
    links[1] = 0
    # 既然初始状态是状态0，就将0作为扩展位上的占位符
    for k in range(2,len(augPattern)):
        # 创建字典的第一项，这一项总是从顶点1回到初始状态的一条边
        s = links[k-1]
        stop = False 
        while s >= 1 and not stop:
            # 该循环一步步扩大模式的检查范围,寻找前缀和后缀的重叠部分
            if augPattern[s] == augPattern[k-1]:
                stop = True 
            else:
                s = links[s]
        links[k] = s + 1
    return links