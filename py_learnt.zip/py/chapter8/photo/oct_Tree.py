import sys 
import os 
from PIL import Image 
def buildAndDisplay():
    im = Image.open("D:\\documents\\code\\vscode\\py\\chapter8\\photo\\bubbles.jpg")
    # PIL中的简单函数Image.open打开已有的图片文件
    w,h = im.size 
    ot = OctTree() 
    for row in range(0,h):
        for col in range(0,w):
            r,g,b = im.getpixel((col,row)) # PIL中的简单函数getpixel--读取像素
            ot.insert(r,g,b)
    # 该循环读取每个像素，并将其加到八叉树
    
    ot.reduce(256) # 调用reduce方法，减少叶子节点，减为256种颜色 
    
    for row in range(0,h):
        for col in range(0,w):
            r,g,b = im.getpixel((col,row))
            nr,ng,nb = ot.find(r,g,b)
            # 在缩小后的八叉树中搜索颜色，并更新图片
            im.putpixel((col,row),(nr,ng,nb))  # PIL中的简单函数 putpixel--写入像素
            # 用量化后的新值替换像素
    im.show() # PIL中的简单函数 show--在屏幕上展示结果

class OctTree:
    def __init__(self):
        self.root = None    # 将根节点初始化为None
        self.maxLevel = 5   # 重要属性1--maxLevel属性限制了树的总体深度
        self.numLeaves = 0  
        self.leafList = []  # numleaves和leafList记录叶子节点的数目
        # 可直接访问叶子节点，而不用沿着树遍历
    
    def insert(self,r,g,b):
        if not self.root:
            self.root = self.otNode(outer=self)
        self.root.insert(r,g,b,0,self)
    
    def find(self,r,g,b):
        if self.root:
            # 先检查根节点是否存在，然后调用根节点相应的方法
            return self.root.find(r,g,b,0)
    
    def reduce(self,maxCubes):
        while len(self.leafList) > maxCubes:
            # 一直循环，直到叶子列表中的节点数目小于在最终图片中要保留的颜色总数
            smallest = self.findMinCube()
            # 使用辅助函数findMinCube找到OctTree中引用数最少的节点 
            smallest.parent.merge() 
            # 将该节点与其所有的兄弟节点合并成一个节点
            self.leafList.append(smallest.parent)
            self.numLeaves = self.numLeaves + 1
    
    def findMinCube(self):
        minCount = sys.maxsize
        maxLev = 0
        minCube = None 
        for i in self.leafList:
            if i.count <= minCount and i.level >= maxLev:
                minCube = i
                minCount = i.count 
                maxLev = i.level 
        return minCube 
    
    class otNode:
        def __init__(self,parent=None,level=0,outer=None):
            # 该构造方法有3个可选参数
            self.red = 0
            self.green = 0
            self.blue = 0
            self.count = 0 
            # 引用计数count 
            self.parent = parent 
            self.level = level 
            self.oTree = outer 
            # outer指向创建这个节点的OctTree实例的属性
            self.children = [None]*8
            # 二叉树只有左右两个子节点，八叉树则有8个子节点
        
        def insert(self,r,g,b,level,outer):
            if level < self.oTree.maxLevel:
                idx = self.computeIndex(r,g,b,level)
                if self.children[idx] == None:
                    self.children[idx] = outer.otNode(parent = self,
                                                        level= level + 1,
                                                        outer = outer)
                self.children[idx].insert(r,g,b,level+1,outer)
            else:
                if self.count == 0:
                    self.oTree.numLeaves = self.oTree.numLeaves + 1 
                    self.oTree.leafList.append(self)
                self.red += r 
                self.green += g 
                self.blue += b  
                self.count = self.count + 1 
            
        def computeIndex(self,r,g,b,level):
            shift = 8 - level 
            rc = r >> shift - 2 & 0x4 
            # >> 右移操作,& 位运算中的and
            gc = g >> shift - 1 & 0x2 
            bc = b >> shift & 0x1
            return (rc | gc | bc)
            # | 位运算中的 or 
            
        def find(self,r,g,b,level):
            if level < self.oTree.maxLevel:
                idx = self.computeIndex(r,g,b,level)
                if self.children[idx]:
                    return self.children[idx].find(r,g,b,level+1)
                elif self.count > 0:
                    return ((self.red // self.count,
                                self.green // self.count,
                                self.blue // self.count))
                # find方法退出情况2--在小于maxLevel的层上找到一个叶子节点
                else:
                    print("error: No leaf node for this color")
                # find方法退出情况3--路径导向不存在的子树--这是个错误 
            else:
                return ((self.red // self.count,
                            self.green // self.count,
                            self.blue // self.count))
                # find方法退出情况1--到达maxLeave层,返回叶子节点中颜色信息的平均值

        def merge(self):
            for i in self.children:
                if i:
                    if i.count > 0:
                        self.oTree.leafList.remove(i)
                        self.oTree.numLeaves -= 1
                    else:
                        print("Recursively Merging non-leaf ...")
                    self.count += i.count 
                    self.red += i.red 
                    self.green += i.green  
                    self.blue += i.blue  
            for i in range(8):
                self.children[i] = None 
                
    
buildAndDisplay()  
