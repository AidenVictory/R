## 研究其他类型的逻辑门（例如与非门、或非门、异或门）。将它们加入电路的继承层次结构
class LogicGate:
    def __init__(self,n):
        self.label = n 
        self.output = None
    
    def getLabel(self):
        return self.label
    
    def getOutput(self):
        self.output = self.performGateLogic()
        return self.output

class BinaryGate(LogicGate):
    def __init__(self,n):
        super().__init__(n)
        
        self.pinA = None 
        self.pinB = None
        
    def getPinA(self):
        return int(input("Enter Pin A input for gate" + \
            self.getLabel() + "-->"))
        
    def getPinB(self):
        return int(input("Enter Pin B input for gate" + \
            self.getLabel() + "-->"))

class UnaryGate(LogicGate):
    def __init__(self,n):
        super().__init__(n)
        
        self.pin = None     
    
    def getPin(self):
        return int(input("Enter Pin input for gate" + \
            self.getLabel() + "-->")) 
# 与门
class AndGate(BinaryGate):
    def __init__(self,n):
        super().__init__(n)
        
    def performGateLogic(self):
        
        a = self.getPinA()
        b = self.getPinB()
        if a == 1 & b == 1:
            return 1
        else:
            return 0
# 或门    
class OrGate(BinaryGate):
    def __init__(self,n):
        super().__init__(n)
        
    def performGateLogic(self):
        
        a = self.getPinA()
        b = self.getPinB()
        if a == 0 & b == 0:
            return 0
        else:
            return 1    
# 非门
class NotGate(UnaryGate) :
    def __init__(self,n):
        super().__init__(n)
    
    def performGateLogic(self):
        a = self.getPin()
        if a == 0 :
            return 1
        elif a == 1:
            return 0
# 或非门
class NorGate(BinaryGate):
    def __init__(self,n):
        super().__init__(n)
        
    def performGateLogic(self):
        
        a = self.getPinA()
        b = self.getPinB()
        if a == 0 & b == 0:
            return 1
        else:
            return 0    
# 异或门
class XorGate(BinaryGate):
    def __init__(self,n):
        super().__init__(n)
        
    def performGateLogic(self):
        
        a = self.getPinA()
        b = self.getPinB()
        if a == b:
            return 0
        else:
            return 1
# 同或门
class XNorGate(BinaryGate):
    def __init__(self,n):
        super().__init__(n)
        
    def performGateLogic(self):
        
        a = self.getPinA()
        b = self.getPinB()
        if a == b:
            return 1
        else:
            return 0
# 与非门
class NandGate(BinaryGate):
    def __init__(self,n):
        super().__init__(n)
        
    def performGateLogic(self):
        
        a = self.getPinA()
        b = self.getPinB()
        if a == 1 & b == 1:
            return 0
        else:
            return 1    
     
def main():          
    g1 = AndGate("G1")
    print("AndGate","-",g1.getOutput())       
    g2 = OrGate("G2")
    print("OrGate","-",g2.getOutput())
    g3 = NotGate("G3")
    print("NotGate","-",g3.getOutput())
    g4 = NorGate('G4')
    print("NorGate","或非门","-",g4.getOutput())   
    g5 = XorGate('G5')
    print("XorGate","异或门","-",g5.getOutput())   
    g6 = XNorGate('G6')
    print("XNorGate","异或门","-",g6.getOutput())   
    g7 = NandGate('G7')
    print("NandGate","与非门","-",g7.getOutput())
    
main()