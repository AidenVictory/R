# 构造分数,并进行关系运算和算术运算
class Fraction:
    def __init__(self,top,bottom):
        newtop = abs(top)
        newbottom = abs(bottom)
        if int(top) != float(top) or int(bottom) != float(bottom):
            raise RuntimeError("不适用小数")
        if bottom == 0:
            raise RuntimeError("分母不能为0")
        
        common = self.gcd(newtop,newbottom)
        
        ## 请修改构造方法，使得用户能够传入负的分母，并且所有的运算符都能返回正确的结果
        if top * bottom >0:
            self.num = newtop // common
            self.den = newbottom // common
        else:
            self.num = - newtop // common
            self.den = newbottom // common   
    def __str__(self):
        return str(self.num) + "/" + str(self.den) 
    def gcd(self,m,n):                       # 最大公因数--欧几里得算法
        while m%n != 0:
            oldm = m 
            oldn = n
            
            m = oldn
            n = oldm%oldn
        return n 
    ## 实现简单的方法getNum和getDen，它们分别返回分数的分子和分母 ##
    def getNum(self):
        return str(self.num)
    def getDen(self):
        return str(self.den)
    
    # 算术运算符
    def __add__(self,otherf):
        newnum = self.num * otherf.den + otherf.num * self.den  
        newden = self.den * otherf.den 
        return Fraction(newnum,newden)
    
    def __sub__(self,otherf):
        newnum = self.num * otherf.den - otherf.num * self.den  
        newden = self.den * otherf.den 
        return Fraction(newnum,newden)
    
    def __mul__(self,otherf):
        newnum = self.num * otherf.num 
        newden = self.den *otherf.den
        return Fraction(newnum,newden)
    
    def __truediv__(self,otherf):
        if otherf.num == 0:
            print("error,contradictory to divising rule,otherf.num can not be zero")
            return "illegal"
        else:
            newnum = self.num * otherf.den
            newden = self.den * otherf.num
            return Fraction(newnum,newden)
    
    def __iadd__(self,otherf):
        newnum = self.num * otherf.den + self.den * otherf.num
        newden = self.den * otherf.den 
        return Fraction(newnum,newden)
    
    # 关系运算符
    def __gt__(self,otherf):
        a = self.num * otherf.den - otherf.num * self.den 
        if a > 0:
            return True
        else:
            return False
    def __ge__(self,otherf):
        a = self.num * otherf.den - otherf.num * self.den 
        if a >= 0:
            return True
        else:
            return False
    
    def __lt__(self,otherf):
        a = self.num * otherf.den - otherf.num * self.den 
        if a < 0:
            return True
        else:
            return False
    
    def __le__(self,otherf):
        a = self.num * otherf.den - otherf.num * self.den 
        if a <= 0:
            return True
        else:
            return False
    
    def __ne__(self,otherf):
        a = self.num * otherf.den - otherf.num * self.den 
        if a == 0:
            return False
        else:
            return True
    
    def __eq__(self,otherf):
        a = self.num * otherf.den - otherf.num * self.den 
        if a == 0:
            return True
        else:
            return False
    
if __name__=='__main__': 
    f1 = Fraction(2  ,-8)
    f2 = Fraction(1,8)
    print(f1,"-",f2,"=",f1-f2)
    print(f1,">",f2,"=",f1>f2)
    
    print(f1,"+=",f2,f2.__iadd__(f1))
    print(f1,"+=",f2,f2.__add__(f1))