## 证明列表的索引操作为常数阶
import timeit
import random
import matplotlib.pyplot as plt
import numpy as np

lst_length = []
lst_timer = []
for i in range(10000,1000001,20000):
    t = timeit.Timer("x[random.randrange(%d)]" % i,
                     "from __main__ import random, x")
    x = list(range(i))
    lst_time = t.timeit(number=1000)
    lst_length.append(i)
    lst_timer.append(lst_time)

plt.scatter(lst_length, lst_timer)
plt.show()
print(np.mean(lst_timer))
print(len(lst_timer))