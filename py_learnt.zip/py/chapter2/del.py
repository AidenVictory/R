## 针对列表和字典比较del操作的性能
import timeit
import random
import matplotlib.pyplot as plt
import numpy as np


d_length = []
d_timer = []
d_length2 = []
d_timer2 = []
for i in range(10000,1000001,20000):
    t = timeit.Timer("del x[random.randrange(%d)]" % i,
                     "from __main__ import random, x")
    x = list(range(i))
    d_time = t.timeit(number=1000)
    d_length.append(i)
    d_timer.append(d_time)

    x = {j:None for j in range(i)}
    d_time2 = t.timeit(number=1000)
    d_length2.append(i)
    d_timer2.append(d_time2)
    
plt.scatter(d_length, d_timer)
plt.show()
print(np.mean(d_timer),np.std(d_timer))

plt.scatter(d_length2, d_timer2)
plt.show()
print(np.mean(d_timer2),np.std(d_timer2))
